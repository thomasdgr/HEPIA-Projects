public abstract class Arithmetic extends Binary {
    public Arithmetic(String fl, int line, int col) {
        super(fl, line, col);
    }
}
