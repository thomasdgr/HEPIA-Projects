public interface Calories{
    public String calculCalories(String nom);
}