public interface EtatCommande{
    public abstract void TraiterCommande(Commande maCommande);
}