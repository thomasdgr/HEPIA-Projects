package legumes;

public class LegumePotage implements Legume{
    public LegumePotage(){}

    public void familleLegume(){
        System.out.println("Legume pour potage");
    } 
} 
