package legumes;

public class LegumeCuisson implements Legume{
    public LegumeCuisson(){} 

    public void familleLegume(){
        System.out.println("Legume pour cuisson");
    } 
} 
