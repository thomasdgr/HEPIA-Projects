package legumes;

public class LegumeVapeur implements Legume{
    public LegumeVapeur(){}

    public void familleLegume(){
        System.out.println("Legume pour vapeur");
    } 
} 
