package factory;

import legumes.Legume;

public abstract class Factory{
    public abstract Legume menu(String famille); 
} 
