package herbes;

public interface Herbe {
	public void familleHerbe();
}
