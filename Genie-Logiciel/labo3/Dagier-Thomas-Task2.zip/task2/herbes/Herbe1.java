package herbes;

public class Herbe1 implements Herbe {
    public Herbe1(){} 

	public void familleHerbe() {
		System.out.println("Herbe numéro 1");
	}
}
