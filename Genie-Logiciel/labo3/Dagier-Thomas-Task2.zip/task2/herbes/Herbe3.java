package herbes;

public class Herbe3 implements Herbe {
    public Herbe3(){} 

	public void familleHerbe() {
		System.out.println("Herbe numéro 3");
	}
}