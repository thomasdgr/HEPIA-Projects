package herbes;

public class Herbe4 implements Herbe {
    public Herbe4(){} 

	public void familleHerbe() {
		System.out.println("Herbe numéro 4");
	}
}