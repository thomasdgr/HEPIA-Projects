package herbes;

public class Herbe2 implements Herbe {
    public Herbe2(){} 

	public void familleHerbe() {
		System.out.println("Herbe numéro 2");
	}
}