package huiles;

public class Huile1 implements Huile{
    public Huile1(){}

	public void familleHuile(){
		System.out.println("Huile numéro 1");
	}
}
