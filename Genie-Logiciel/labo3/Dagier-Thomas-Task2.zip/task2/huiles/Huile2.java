package huiles;

public class Huile2 implements Huile{
    public Huile2(){}

	public void familleHuile(){
		System.out.println("Huile numéro 2");
	}
}
