package huiles;

public class Huile4 implements Huile{
    public Huile4(){}

	public void familleHuile(){
		System.out.println("Huile numéro 4");
	}
}
