package huiles;

public class Huile3 implements Huile{
    public Huile3(){}

	public void familleHuile(){
		System.out.println("Huile numéro 3");
	}
}
