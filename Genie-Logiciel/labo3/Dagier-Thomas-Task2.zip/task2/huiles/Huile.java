package huiles;

public interface Huile {
	public void familleHuile();
}
