package legumes;

public class LegumeSalade implements Legume{
    public LegumeSalade(){}

    public void familleLegume(){
        System.out.println("Legume pour salade");
    } 
} 