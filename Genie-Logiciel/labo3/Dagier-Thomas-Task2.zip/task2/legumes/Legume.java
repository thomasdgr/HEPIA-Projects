package legumes;

public interface Legume{
    public void familleLegume();
} 
