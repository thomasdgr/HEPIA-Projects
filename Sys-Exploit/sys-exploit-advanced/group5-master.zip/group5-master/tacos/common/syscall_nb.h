 #ifndef _SYSCALL_NB_COMMON_H_
#define _SYSCALL_NB_COMMON_H_

typedef enum { 
    SYSCALL_puts = 0,
    SYSCALL_exec = 1,
    SYSCALL_getc = 2,
    SYSCALL_file_stat = 3,
    SYSCALL_file_read = 4,
    SYSCALL_sleep = 5,
    __SYSCALL_END__
} syscall_t;

#endif