#include <stdbool.h>
#include "stdio.h"
#include "types.h"

int itoa(int val, char *buf, int base, bool sign) {
	static char digits[] = "0123456789ABCDEF";
	int count = 0;
	uint_t x;

	if (sign && (sign = val < 0))
		x = -val;
	else
		x = val;

	do {
		buf[count++] = digits[x % base];
	} while ((x /= base) != 0);

	if (sign)
		buf[count++] = '-';

    for (int i = 0; i < count/2; i++) {
        char tmp = buf[i];
        buf[i] = buf[count-i-1];
        buf[count-i-1] = tmp;
    }

	buf[count] = 0;
	return count;
}

void sprintf(char *buf, const char *fmt, va_list ap) {
    char valstr[32];
    char *p, *str;
    int val;
    for (p = (char *)fmt; *p; p++) {
        if (*p != '%') {
            *buf = *p;
            buf++;
            continue;
        }
        p++;
        switch (*p) {
            case 'd':
                val = va_arg(ap, int);
                str = valstr;
                itoa(val, str, 10, true);
                while (*str) { *buf++ = *str++; }
                break;
            case 'x':
                val = va_arg(ap, int);
                str = valstr;
                itoa(val, str, 16, false);
                while (*str) { *buf++ = *str++; }
                break;
            case 'c':
                val = va_arg(ap, int);
                *buf = val;
                buf++;
                break;
            case 's':
                str = va_arg(ap, char *);
                while (*str) { *buf++ = *str++; }
                break;
            default:
                *buf = *p;
                buf++;
        }
    }

    *buf = '\0';

    va_end(ap);
}