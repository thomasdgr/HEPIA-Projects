#ifndef _STDIO_COMMON_H_
#define _STDIO_COMMON_H_

#include <stdarg.h>

// Converts an integer into a string using the specified base and sign.
// Returns the number of characters written (excluding the zero end-of-string).
extern int itoa(int val, char *buf, int base, bool sign);

// Minimal sprintf implementation.
// Supported formats: %c, %s, %d, %x
// SECURITY WARNING: this function might overflow the input buffer buf!
extern void sprintf(char *buf, const char *fmt, va_list ap);

#endif