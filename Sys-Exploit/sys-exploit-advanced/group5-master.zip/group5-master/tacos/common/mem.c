#include <stdint.h>
#include "mem.h"

void memsetb(void *dst, uint8_t value, uint_t count) {
	uint8_t *d = dst;
	while (count--)
		*d++ = value;
}

void memsetd(void *dst, uint16_t value, uint_t count) {
	uint16_t *d = dst;
	while (count--)
		*d++ = value;
}

void memsetdw(void *dst, uint32_t value, uint_t count) {
	uint32_t *d = dst;
	while (count--)
		*d++ = value;
}

void memcpyb(void *dst, void *src, uint_t count) {
	uint8_t *d = dst;
	uint8_t *s = src;
	while (count--)
		*d++ = *s++;
}

void memcpydwm(void *dst, void *src, uint_t count) {
	uint32_t *d = dst;
	uint32_t *s = src;
	while (count--)
		*d++ = *s++;
}

void memcpydw(void *dst, void *src, uint_t count) {
	uint16_t *d = dst;
	uint16_t *s = src;
	while (count--)
		*d++ = *s++;
}