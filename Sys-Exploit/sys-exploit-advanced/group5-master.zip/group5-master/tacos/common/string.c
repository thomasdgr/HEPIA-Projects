/**
* @file string.c
* @brief native string management
*
* Allow to manipulate char*,
* added the strtok function used to parse grub's module arguments
*
* @author Dagier Thomas, Bernasconi Dorian
* @bug No known bugs.
* @date 24.01.2022
* @version 1.0
*/

#include <stdint.h>
#include "string.h"

uint_t strlen(const char *s) {
	int n;
	for (n = 0; s[n]; n++);
	return n;
}

char *strncpy(char *dest, const char *src, uint_t count) {
	char *p = dest;
	
	while (count && *src) {
		*p = *src;
		src++;
		p++;
		count--;
	}
	*p = 0;
	return dest;
}

// Original FreeBSD implementation
// Source: https://github.com/freebsd/freebsd/blob/master/lib/libc/string/strcmp.c
int strcmp(const char *s1, const char *s2) {
	while (*s1 == *s2++)
		if (*s1++ == '\0')
			return (0);
	return (*(const unsigned char *)s1 - *(const unsigned char *)(s2 - 1));
}

// Original FreeBSD implementation
// Source: https://github.com/freebsd/freebsd/blob/master/lib/libc/string/strncmp.c
int strncmp(const char *s1, const char *s2, uint_t n) {
	if (n == 0)
		return (0);
	do {
		if (*s1 != *s2++)
			return (*(const unsigned char *)s1 -
				*(const unsigned char *)(s2 - 1));
		if (*s1++ == '\0')
			break;
	} while (--n != 0);
	return (0);
}

uint_t atoi(const char *s) {
	uint_t n = 0;
	while ('0' <= *s && *s <= '9')
		n = n*10 + *s++ - '0';
	return n;
}

char *tolower(char *s) {
	for (int n = 0; s[n]; n++) {
		if (s[n] >= 'A' && s[n] <= 'Z') {
            // upper case letters differ by 32 from lower case ones (man ascii)
			s[n] = s[n] + 32;
        }
	}
	return s;
}

/**
* Check if the char "c" is in string "str" at least once.
* @param c char we want to find in string given 
* @param str string that might contains the char given.
* @return "true" if the char is in string at least once, else "false".
*/
bool contains(char c, char* str){
    for(uint_t i = 0; i < strlen(str); i++){
        if(c == str[i]){
            return true;
        }
    }
    return false;
}

/**
* Break a string into a sequence of zero or more nonempty tokens.
* @param str string that we want to separate
* @param separators one or more char that we use to separate the string given.
* @return a pointer to the next  token, or NULL if there are no more tokens.
*/
char* strtok(char* str, char* separators){
    static char* tmp;
    if(!str){
        str = tmp;
    }
    if(!str){
        return NULL;
    }
    while(1){
        if(contains(*str, separators)){
            str++;
            continue;
        }
        if(*str == '\0'){
            return NULL; 
        }
        break;
    }
    char* ret = str;
    while(1){
        if(*str == '\0'){
            tmp = str;
            return ret;
        }
        if(contains(*str, separators)){
            *str = '\0';
            tmp = str + 1;
            return ret;
        }
        str++;
    }
}

/**
* Trim a string with the 'space' separator
* @param line string that we want to trim
* @return the trimed string
*/
char *trim(char *line) {
	int len;
	while (*line == ' ')
		line++;
	len = strlen(line);
	if (len > 0) {
		char *s = line + len - 1;
		int cut = 0;
		while (*s == ' ') {
			s--;
			cut = 1;
		}
		if (cut) {
			*(s + 1) = 0;
		}
	}
	return line;
}