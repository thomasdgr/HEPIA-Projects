## Description

TacOS is a very basic operating system for the Intel IA-32 architecture (i386 and above).

## Building and running TacOS

Several programs and tools are required to successfully build and run TacOS:

- make
- binutils
- gcc
- nasm
- lib32gcc-9-dev
- libc6-dev-i386
- genisoimage
- xorriso
- mtools
- qemu-system-x86

On a Ubuntu 20.04 system, this means installing the following packages:

```
sudo apt-get install --no-install-recommends make binutils gcc nasm lib32gcc-9-dev libc6-dev-i386 genisoimage xorriso mtools qemu-system-x86
```

Then, to build and run TacOS in QEMU, simply type:

```
make run
```

If you'd like to run TacOS on a physical machine, type the following to build it and deploy it to a USB stick (for instance /dev/sdb):
```
make PLATFORM=PC DEBUG=0 DEV=/dev/sdb deploy
```

To display the various build options, type `make`:
```
Available targets:
run      build the OS ISO image (+ filsystem) and run it in QEMU
iso      build the OS ISO image (+ filesystem)
common   build the common object files only
kernel   build the kernel only
user     build the user space executables only
tools    build the host tools only
debug    build the OS ISO image (+ filsystem) and run it in QEMU for debugging
deploy   build the OS ISO image (+ filsystem) and deploy it to the specified device
         Requires DEV to be defined (eg. DEV=/dev/sdb)
clean    clean up everything

Available variables:
SYSTEM   target system type, either UEFI or BIOS (default: UEFI)
PLATFORM target platform type, either QEMU or PC (default: QEMU)
DEBUG    whether to generate debug code, either on or off (default: on)
DEV      device to deploy the ISO image onto (only used by the "deploy" target)

Usage examples:
make run
make run SYSTEM=BIOS PLATFORM=QEMU
make PLATFORM=PC DEBUG=0 DEV=/dev/sda deploy
```
