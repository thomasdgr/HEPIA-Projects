#include "common/mem.h"
#include "mem/paging.h"
#include "task.h"
#include "tss.h"

// array of tasks used so tasks can have their own memory space
static task_t tasks[MAX_TASK_COUNT];
// index of the current task
static uint32_t index = 0;

static tss_t initial_tss;
static uint8_t initial_tss_kernel_stack[65536];

/**
* Create a task
* @param t output argument where the created task is returned
* @param gdt_task_tss output argument filled with the task's TSS descriptor
* @param p_addr the phys
* @param task_size the size of the task (in bytes)
*/
static void task_create(task_t* t, gdt_entry_t *gdt_task_tss, void* p_addr, uint32_t task_size){
    // Clears the whole task_t structure
	memsetb(t, 0, sizeof(task_t));
	
    // Add the task's TSS to the GDT
	int gdt_tss_sel = gdt_entry_to_selector(gdt_task_tss);
	*gdt_task_tss = gdt_make_tss(&t->tss, DPL_KERNEL);
	
    // Store the TSS selector for easy referencing later when loading the task register
	t->tss_selector = gdt_tss_sel;
	
    // Initialize the TSS fields
	tss_t *tss = &t->tss;
	
    // User code and data segments
	tss->cs = GDT_USER_CODE_SELECTOR;
	tss->ds = tss->es = tss->gs = tss->ss = GDT_USER_DATA_SELECTOR;

    // Page directory
    t->tss.cr3 = (uint32_t)t->pagedir;

    // Activate hardware interrupts (bit 9)
    t->tss.eflags = (1 << 9);

    // Setup the task's kernel stack
    t->tss.ss0 = GDT_KERNEL_DATA_SELECTOR;
    t->tss.esp0 = (uint32_t)(t->kernel_stack) + sizeof(t->kernel_stack);

    // Initialize code (t->tss.eip) and stack pointers (t->tss.esp and t->tss.ebp)
    t->tss.eip = TASK_VIRT_ADDR;
    t->tss.esp = TASK_VIRT_ADDR + task_size + STACK_SIZE;
    t->tss.ebp = t->tss.esp;

    // Create RAM and SVGA identity mappings
    multiboot_info_t *mbi = multiboot_get_info();
    map(0, 0, mbi->mem_upper / 4, PRIVILEGE_KERNEL, t->pagedir);

    // Framebuffer mapping at 3GB + identity mapping
    uint32_t fb_size = (get_framebuffer_size() * (mbi->framebuffer_bpp / 8)) / PAGE_SIZE;
    map(FB_VIRT_ADDR_IN_TASK, mbi->framebuffer_addr, fb_size, PRIVILEGE_USER, t->pagedir);
    map(mbi->framebuffer_addr, mbi->framebuffer_addr, fb_size, PRIVILEGE_USER, t->pagedir);

    // Task mapping at 1GB
    uint32_t nb_frames = (task_size + STACK_SIZE + PAGE_SIZE-1) / PAGE_SIZE;
    map(TASK_VIRT_ADDR, (uint32_t)p_addr, nb_frames, PRIVILEGE_USER, t->pagedir);
}

/**
* Execute a task loaded with grub
* @param cmd output argument filled with the task's TSS descriptor
*/
void exec_task(char* cmd){
    int task_index = get_module_index(cmd);
    if(task_index >= 0){
        uint32_t task_size = multiboot_get_module_size(task_index);
        uint32_t nb_frames = (task_size + STACK_SIZE + FRAME_SIZE-1) / FRAME_SIZE;
        void* task_physical_addr = alloc(nb_frames);
        task_t* t = &tasks[index++];
        memcpyb(task_physical_addr, multiboot_get_module_addr(task_index), task_size);
        task_create(t, gdt_get_first_free_entry(), task_physical_addr, task_size);
        task_switch(t->tss_selector);
        free(task_physical_addr, nb_frames);
        gdt_free_last_used_entry();
        free_pagedir_frames(t);
        index--;
    } else {
        printf("executable file %s not found\n", cmd);
    }
}

/**
* Free the used frames from the pagedir of the current task
* @param t the current task
*/
void free_pagedir_frames(task_t* t){
    for(uint32_t i = 0; i < PAGETABLE_COUNT; i++){
        if(t->pagedir[i].pagetable_base_addr > 0){
            free_frame((void*)(t->pagedir[i].pagetable_base_addr<<12));
        }
        t->pagedir[i].pagetable_base_addr = 0;
    }
}

/**
* Setup the inital tss
*/
void task_setup_initial_tss() {
    extern gdt_entry_t *gdt_initial_tss;

	// Entry for initial kernel TSS (CPU state of first task saved there)
	*gdt_initial_tss = gdt_make_tss(&initial_tss, DPL_KERNEL);
	memsetb(&initial_tss, 0, sizeof(tss_t));
	initial_tss.ss0 = GDT_KERNEL_DATA_SELECTOR;
	initial_tss.esp0 = ((uint32_t)initial_tss_kernel_stack) + sizeof(initial_tss_kernel_stack);
	initial_tss.cr3 = (uint32_t)get_kernel_pagedir();

	// Load the task register to point to the initial TSS selector.
	// IMPORTANT: The GDT must already be loaded before loading the task register!
	task_ltr(gdt_entry_to_selector(gdt_initial_tss));
}