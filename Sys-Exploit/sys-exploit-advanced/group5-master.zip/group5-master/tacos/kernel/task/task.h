#ifndef _TASK_H_
#define _TASK_H_

#include "common/types.h"
#include "tss.h"

#include "mem/paging.h"
#include "mem/gdt.h"
#include "descriptors.h"

// Virtual address (1GB) where task user code/data is mapped (i.e. application entry point)
#define TASK_VIRT_ADDR 0x40000000

#define FB_VIRT_ADDR_IN_TASK 0xC0000000

#define STACK_SIZE 65536 // 64kb of memory

typedef pagetable_t PDE_t;

// A task has these associated structures:
// - A TSS structure (tss_t) that saves its state (context)
// - A TSS descriptor present in the GDT (which points to the tss_t structure)
// - A page directory
typedef struct {
	PDE_t pagedir[PAGETABLE_COUNT] __attribute__((aligned(4096)));  // Task page directory
	tss_t tss __attribute__((aligned(4096)));   // Context of the task (must not cross a page boundary!)
	bool in_use;                        // whether the task slot is in use or free
	uint16_t tss_selector;              // selector required when switching to the task
	uint8_t kernel_stack[65536];        // kernel stack
    // you probably want more things than the above...
} __attribute__((aligned(4))) task_t;

extern void task_ltr(uint16_t tss_selector);     // Implemented in task_asm.s
extern void task_switch(uint16_t tss_selector);  // implemented in task_asm.s

// Setup the inital tss
void task_setup_initial_tss();
// Execute a task loaded with grub
void exec_task(char* cmd);
// Free task pagedir
void free_pagedir_frames(task_t* t);

#endif
