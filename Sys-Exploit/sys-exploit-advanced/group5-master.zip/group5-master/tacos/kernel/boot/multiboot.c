/**
* @file multiboot.c
* @brief utilities for the struct multiboot_info_t
* that refers all kernel infos
*
* Allow to get informations from modules loaded by grub,
* the RAM and the kernel informations in general
* 
* @author Dagier Thomas, Bernasconi Dorian
* @bug No known bugs.
* @date 24.01.2022
* @version 1.0
*/

#include "multiboot.h"
#include "./common/string.h"

// object is static as we don't want to instantiate a new object
// every time we call a function taht need it
static multiboot_info_t *mbi;

/**
* Return an object containing all kernel infos
* @return the object
*/
multiboot_info_t* multiboot_get_info(){
	return mbi;
}

/**
* Set the multiboot object from an instantiate one given
* @param  mbi the structure that contains kernel infos 
*/
void multiboot_set_info(multiboot_info_t *_mbi){
    mbi = _mbi;
}

/**
* Return the total amount of RAM available excluding the kernel and grub modules 
* @return the total amount of RAM 
*/
uint_t multiboot_get_RAM_in_KB(){
	return mbi->mem_lower + mbi->mem_upper;
}

/**
* Return the number of module loaded by grub 
* @return the number of module loaded 
*/
multiboot_uint8_t multiboot_get_module_count(){
	return mbi->mods_count;
}

/**
* Return the start address of a module given from an index 
* @param index the index of a module loaded by grub
* @return the address of the module 
*/
void* multiboot_get_module_addr(multiboot_uint32_t index){
	return (void*)((multiboot_module_t*) mbi->mods_addr)[index].mod_start;
}

/**
* Return the size of a module in KB given from an index
* @param index the index of a module loaded by grub
* @return the size of the module 
*/

multiboot_uint32_t multiboot_get_module_size(multiboot_uint32_t index){
	multiboot_module_t mod = ((multiboot_module_t*) mbi->mods_addr)[index];
	return mod.mod_end - mod.mod_start;
}

/**
* Return a string that contains the command line of a module given from an index
* @param index the index of a module loaded by grub
* @return the string that contains the command line
*/
char* multiboot_get_cmd(multiboot_uint32_t index){
	return (char*)((multiboot_module_t*) mbi->mods_addr)[index].cmdline;
}

/**
* Return the number of arguments from a module command line
* @param cmd the string that contains the command line
* @param separator the char used to separate arguments in command line
* @return the number of arguments
*/
multiboot_uint8_t get_number_of_args_from_cmd(char* cmd, char separator){
    multiboot_uint8_t count = 0;
    for(multiboot_uint8_t i = 0; i < strlen(cmd); i++){
        if(cmd[i] == separator){
            count++;
        }
    }
    return strlen(cmd) > 0 ? (count + 1) : count;
}

/**
* From the command line and a static initialized array of string,
*   append each argument in the "ptr" array 
* @param cmd the string that contains the command line
* @param ptr the array of string used to store each arguments
*/
void parse_cmd(char* cmd, char** ptr){
	multiboot_uint8_t i = 1;
    *ptr = strtok(cmd, " ");
    while(*(ptr + i) != NULL){
        *(ptr + i) = strtok(NULL, " ");
        i++;
    }
}

/**
* Return the end address of the last module loaded by grub 
* @return the address of the last module
*/
void* multiboot_get_module_final_addr(){
	return (void*)(((multiboot_module_t*)(mbi->mods_addr)+multiboot_get_module_count()))->mod_end;
}

/**
* Return the size of the framebuffer
* @return the size
*/
uint32_t get_framebuffer_size(){
    return mbi->framebuffer_width * mbi->framebuffer_height;
}

/**
* Return a module by his name
* @param name the name of the file given as a command in grub.cfg
* @return the index of the module found or 0
*/
int get_module_index(char* name){
    for(uint32_t i = 0; i < multiboot_get_module_count(); i++){
        char* cmd = multiboot_get_cmd(i);
        if(strcmp(name, cmd)==0){
            return i;
        }
    }
    return -1;
}