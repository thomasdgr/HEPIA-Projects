#ifndef _MULTIBOOT_H_
#define _MULTIBOOT_H_

#include "common/types.h"
#include "multiboot_structs.h"

// return a pointer on a multiboot_info_t object containing all kernel infos
extern multiboot_info_t* multiboot_get_info();
// set the kernel infos from a given pointer on a multiboot_info_t object 
extern void multiboot_set_info(multiboot_info_t *_mbi);
// return the total amount of RAM available excluding the kernel and grub modules
extern uint_t multiboot_get_RAM_in_KB();

// return the number of module loaded by grub
multiboot_uint8_t multiboot_get_module_count();
// return the start address of a module given from an index 
void* multiboot_get_module_addr(multiboot_uint32_t index);
// return the size of a module in KB given from an index
multiboot_uint32_t multiboot_get_module_size(multiboot_uint32_t index);
// return a string that contains the command line of a module given from an index
// the command line is written in grub.cfg
char* multiboot_get_cmd(multiboot_uint32_t index);
// return the number of arguments from a module command line
multiboot_uint8_t get_number_of_args_from_cmd(char* cmd, char separator);
// from the command line and an initialized array of string
// append each argument in the "ptr" object 
void parse_cmd(char* cmd, char** ptr);
// return the end address of the last module loaded by grub 
void* multiboot_get_module_final_addr();
// Return the size of the framebuffer
uint32_t get_framebuffer_size();
// Retrun the index of a module by its name
int get_module_index(char* name);

#endif
