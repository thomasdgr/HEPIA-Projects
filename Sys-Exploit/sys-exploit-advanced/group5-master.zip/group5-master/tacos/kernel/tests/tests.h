#ifndef _TESTS_H_
#define _TESTS_H_

#include "interrupt/idt.h"
#include "task/task.h"

// Fuction used to test if display is working fine
void test_display();
// Function used to test if alloc of x frames and free is working fine
void test_fram_alloc_and_free();
// Display the mapped physical address corresponding to the given virtual address
void test_paging(uint32_t v_addr);
// Function used to test if the timer part (including interrupt) is working fine
void test_timer();
// Function used to test if the task part is working fine
void test_task();

#endif
