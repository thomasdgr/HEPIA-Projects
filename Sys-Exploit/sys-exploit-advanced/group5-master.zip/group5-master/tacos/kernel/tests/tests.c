/**
* @file tests.c
* @brief Testing all implementation from part 1.
*
* Currently test display, memory mapping, frames,
* vertical scrolling and timer interrupt
*
* @author Dagier Thomas, Bernasconi Dorian
* @bug No known bugs.
* @date 04.02.2022
* @version 1.0
*/

#include "tests.h"

/**
* Fuction used to test if display is working fine
*/
void test_display(){
    set_text_color(LIGHT_BLUE);
    set_text_background_color(WHITE);
    printf("Thomas et Dorian\n");
    set_text_color(RED);
    set_text_background_color(LIGHT_BLUE);
    printf("Thomaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaas et Doriaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaan\n");
    set_text_color(WHITE);
    //set_background_color(GREEN);
    for(uint8_t i = 0; i < 10; i++){
        printf("\n");
    }
}

/**
* Function used to test if alloc of x frames and free is working fine
*/
void test_fram_alloc_and_free(){
    void* addr = alloc(1);
    printf("alloc 1 frame at 0x%x\n", addr);
    printf("alloc 2 frames at 0x%x\n", alloc(2));
    free_frame(addr);
    printf("free frame at address 0x%x\n", addr);
    printf("alloc 2 frames at 0x%x\n", alloc(2));
}

/**
* Display the mapped physical address corresponding to the given virtual address
* @param v_addr the virtual address
*/
void test_paging(uint32_t v_addr){
    uint32_t index_in_pde = ADDR_TO_PAGETABLE(v_addr) & 0x3FF;
    uint32_t index_in_pte = ADDR_TO_PAGE(v_addr) & 0x3FF;
    uint32_t offset = v_addr & 0xFFF;
    page_t* page = (page_t*)(get_kernel_pagedir()[index_in_pde].pagetable_base_addr << 12);
    uint32_t p_addr = (page[index_in_pte].page_base_addr << 12) + offset;
    printf("address 0x%x is mapped at address 0x%x\n", v_addr, p_addr);
}

/**
* Function used to test if the timer part (including interrupt) is working fine
*/
void test_timer() {
	for(uint8_t i = 0; i < 10; i++) {
		timer_sleep(1000);	
		printf("%d sec -> %d ticks\n", i+1, timer_get_ticks());
	}
}

/**
* Function used to test if the task part is working fine
*/
void test_task(){
    exec_task("test");
}