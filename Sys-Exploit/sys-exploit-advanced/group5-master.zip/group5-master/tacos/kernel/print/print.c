/**
* @file print.c
* @brief utilities for the display part
*
* Print, coloration, background settings,
* Scroll, Shift, Draw logo from a grub module 
* 
* @author Dagier Thomas, Bernasconi Dorian
* @bug No known bugs.
* @date 24.01.2022
* @version 1.0
*/

#include "print.h"

// object is static as we want to keep information about
// the position of the index where to write the next time
static uint32_t last_x = 0;

// objects are static as we want to keep in mind the colors
// when we want to print again
static uint16_t txt_color;
static uint16_t bg_color;
static uint16_t txt_bg_color;

// object is static as we don't want to instantiate a new object
// every time we call a function that need it
static multiboot_info_t *mbi;

/**
* Initialize display by setting a color to the text, 
*    the backgroud and the mbi structure
* @param bg_color background color
* @param txt_color text color
*/
void init_display(uint16_t bg_color, uint16_t txt_color){
    mbi = multiboot_get_info();
    clear(bg_color);
    set_text_color(txt_color);
}

/**
* Knowing the coordinate, update a pixel on the framebuffer 
*    with a specific color 
* @param x the first coordinate
* @param y the first coordinate
* @param color the color of the pixel
*/
void print_pixel(uint32_t x, uint32_t y, uint16_t color){
    ( (uint16_t*) mbi->framebuffer_addr)[x + (y  * mbi->framebuffer_width)] = color;
}

/**
* Clear the whole screen by setting a color on all pixels in the framebuffer
* @param color the color of the background
*/
void clear(uint16_t color){
    memsetd((uint16_t*)mbi->framebuffer_addr, color, get_framebuffer_size());
    set_text_background_color(color);
    set_background_color(color);
}

/**
* Set the color of the text that will be printed later
* @param new_color the color of the text to set
*/
void set_text_color(uint16_t new_color){
    txt_color = new_color;
}

/**
* From an ascii number print a char at a specific position in the framebuffer
* @param asci the color of the text
* @param x_offset the color of the text
*/
void text(uint32_t asci, uint32_t x_offset){ 
     
    for(int i = 0; i < FONT_HEIGHT; i++){
        uint8_t c = font_8x16[(FONT_HEIGHT * asci) + i];
        for(int j = FONT_WIDTH - 1; j >= 0; j--){
            if((c & (1 << j)) != 0){
                print_pixel(x_offset + (FONT_WIDTH - j), i, txt_color);
            }else{
                print_pixel(x_offset + (FONT_WIDTH - j), i, txt_bg_color);
            }
        }
    }
}

/**
* Print to the screen the string according to the arguments given
* @param txt the text that will be print
* @param ... dynamic agruments (of type %d, %s, %x, %c)
*/
void printf(char* txt, ...){
    va_list args;
    va_start(args, txt);
    char buf[256] = "";
    sprintf(buf, txt, args);
    va_end(args);
    for(uint_t i = 0; i < strlen(buf); i++){
        if(last_x >= get_framebuffer_size()){
            shift_screen();
        }
        if((int) buf[i] == 0x0A){
            last_x += mbi->framebuffer_width * FONT_HEIGHT;
            last_x -= last_x % mbi->framebuffer_width;
        } else if (!strcmp("\b",&buf[i])){
            int shift = FONT_WIDTH;
            if(last_x % mbi->framebuffer_width == 0){
                shift += mbi->framebuffer_width * (FONT_HEIGHT - 1);
            }
            last_x -= shift;
            text(bg_color,last_x);
        } else{
            text((uint32_t)buf[i], last_x);
            last_x += FONT_WIDTH;
            if(!(last_x % mbi->framebuffer_width)){
                last_x += mbi->framebuffer_width * (FONT_HEIGHT - 1);
            }
        }
    }
}



/**
* Simulate vertical scrolling by updating the framebuffer
*/
void shift_screen(){
    uint16_t* buffer = (uint16_t*)(mbi->framebuffer_addr);
    uint32_t size = get_framebuffer_size();
    uint32_t offset = mbi->framebuffer_width * FONT_HEIGHT;
    for(uint32_t i = 0; i < size; i++){
        buffer[i] = (i < size - offset) ? buffer[i + offset] : bg_color;
    }
    last_x -= offset;
}

/**
* Print an image at a specific position knowing his size given in an array of string
*    The array should store the size of the image, the data should be pointed 
*    By the address of a module given by the index
* @param ptr the array of string that should contains the size of the image
* @param x_offset coordinate for where to start printing the image
* @param y_offset coordinate for where to start printing the image
* @param index_module index of the module (should be refering the image module)
*/
void display_image(char** ptr, uint32_t x_offset, uint32_t y_offset, uint8_t index_module){
    uint32_t width = atoi(*(ptr));
    uint32_t height = atoi(*(ptr+1));
    uint32_t* image = multiboot_get_module_addr(index_module);
    uint16_t *buffer = (uint16_t*)mbi->framebuffer_addr;
    for(uint32_t i = 0; i < height; i++){
        for(uint32_t j = 0; j < width; j++){
            uint32_t rgba_pixel = image[(i * width) + j];
            uint32_t bg_pixel = buffer[j + ((y_offset + i) * mbi->framebuffer_width) + x_offset];
            print_pixel(x_offset + j, y_offset + i, convert_pixel(rgba_pixel, bg_pixel));
        }
    }
}

/**
* Return the new pixel from the rgba read in the image module data and the current
*    background pixel color
* @param rgba_pixel the pixel read from the image
* @param bg_pixel the current background pixel
*/
uint16_t convert_pixel(uint32_t rgba_pixel, uint32_t bg_pixel){
    // the bytes are in little endian on Intel x32 so we read as "abgr" instead of "rgba"
    uint32_t opacity = ((rgba_pixel >> 24) & 0xFF) / COLOR_MAX_VALUE;
    uint32_t img_b = ((rgba_pixel >> 16) & 0xFF) * (opacity);
    uint32_t img_g = ((rgba_pixel >> 8) & 0xFF) * (opacity);
    uint32_t img_r = (rgba_pixel & 0xFF) * (opacity);

    uint32_t bg_r = ((bg_pixel >> 11) & 0b11111) * (1 - opacity);
    uint32_t bg_g = ((bg_pixel >> 5) & 0b111111) * (1 - opacity);
    uint32_t bg_b = ((bg_pixel     )  & 0b11111) * (1 - opacity);
    
    return RGB(img_r, img_g, img_b) + RGB(bg_r << 3,bg_g << 2,bg_b << 3);
}

/**
* Set the background color but let the text printed on screen
* @param new_color the color of the background to set
*/
void set_background_color(uint16_t new_color){
    bg_color = new_color;
    uint16_t *buffer = (uint16_t*)mbi->framebuffer_addr;
    // set the background color but doesn't override the current text
    for(uint32_t i = 0; i < mbi->framebuffer_width; i++){
        for(uint32_t j = 0; j < mbi->framebuffer_height; j++){
            if(buffer[i + (j * mbi->framebuffer_width)] != txt_color){
                print_pixel(i, j, bg_color);
            }
        }
    }
}

/**
* Set the background color of the text that will be printed later
* @param new_color the color of the text to set
*/
void set_text_background_color(uint16_t new_color){
    txt_bg_color = new_color;
}