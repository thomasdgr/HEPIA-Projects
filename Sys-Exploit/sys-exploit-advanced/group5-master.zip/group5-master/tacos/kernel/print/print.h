#ifndef _PRINT_H_
#define _PRINT_H_

#include "drivers/font.h"
#include "boot/multiboot.h"
#include "common/colors.h"
#include "common/stdio.h"
#include "common/mem.h"
#include "common/string.h"

// Initialize display by setting a color to the text, the backgroud and the mbi structure
void init_display(uint16_t bg_color, uint16_t txt_color);
// Knowing the coordinate, update a pixel on the framebuffer with a specific color
void print_pixel(uint32_t x, uint32_t y, uint16_t color);
// Clear the whole screen by setting a color on all pixels in the framebuffer
void clear(uint16_t color);
// Set the color of the text that will be printed later
void set_text_color(uint16_t newColor);
// From an ascii number print a char at a specific position in the framebuffer
void text(uint32_t asci, uint32_t start_draw);
// Print to the screen the string according to the arguments given (like the real printf) 
void printf(char* txt, ...);
// Simulate vertical scrolling
void shift_screen();
// Print an image at a specific position knowing his size given in an array of string
// The array should store the size of the image, the data should be pointed 
// by the address of a module given by the index
void display_image(char** ptr, uint32_t x_offset, uint32_t y_offset, uint8_t index_module);
// Return the converted pixel from the rgba data given and the current background pixel color
uint16_t convert_pixel(uint32_t rgba_pixel, uint32_t bg_pixel);
// Set the new background color but let the text printed on screen
void set_background_color(uint16_t new_color);
// Set the background color of the text that will be printed later
void set_text_background_color(uint16_t new_color);

#endif