#ifndef _IRQ_H_
#define _IRQ_H_

#include "common/types.h"

#define IRQ_FIRST    0
#define IRQ_LAST     15

typedef struct handler_st {
	void (*func)(void);
	char name[64];
} handler_t;

void irq_init();
void irq_install_handler(uint_t irq, handler_t handler);
handler_t *irq_get_handler(uint_t irq);

#endif