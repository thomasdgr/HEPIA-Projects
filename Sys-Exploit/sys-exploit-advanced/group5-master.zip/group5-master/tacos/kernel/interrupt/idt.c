/**
* @file idt.c
* @brief Function handling exceptions, interrupt
*
* Initialize the IDT with fatal exceptions, hardware
*   interrupts... 
*
* @author Dagier Thomas, Bernasconi Dorian
* @bug No known bugs.
* @date 04.02.2022
* @version 1.0
*/

#include "idt.h"

// Gates table
static idt_entry_t idt[INTERRUPT_COUNT];   
static idt_ptr_t   idt_ptr;

// Build and return an IDT entry.
// selector is the code segment selector to access the ISR
// offset is the address of the ISR (for task gates, offset must be 0)
// type indicates the IDT entry type
// dpl is the privilege level required to call the associated ISR
static idt_entry_t idt_build_entry(uint16_t selector, uint32_t offset, uint8_t type, uint8_t dpl) {
	idt_entry_t entry;
	entry.offset15_0 = offset & 0xffff;
	entry.selector = selector;
	entry.reserved = 0;
	entry.type = type;
	entry.dpl = dpl;
	entry.p = 1;
	entry.offset31_16 = (offset >> 16) & 0xffff;
	return entry;
}

static char *exception_names[EXCEPTION_COUNT] = {
	"Divide Error",
	"Reserved",
	"NMI Interrupt",
	"Breakpoint",
	"Overflow",
	"Bound Range Exceeded",
	"Invalid Opcode",
	"Device Not Available (No Math Coprocessor)",
	"Double Fault",
	"Coprocessor Segment Overrun",
	"Invalid TSS",
	"Segment Not Present",
	"Stack Segment Fault",
	"General Protection Fault",
	"Page Fault",
	"Intel Reserved1",
	"x87 FPU Error",
	"Alignment Check",
	"Machine Check",
	"SIMD Exception",
	"Virtualization Exception"
};

/**
* Exception handler, display a fatal error message and stop the kernel
* @param regs CPU context used when saving/restoring context from an interrupt
*/
void exception_handler(regs_t *regs){
	if(regs->number <= EXCEPTION_COUNT){
		printf("Exception %d: %s\n", regs->number, exception_names[regs->number]);
		if(gdt_is_task_entry()){
			*((uint32_t*)regs->eip) = 0xCF;
		} else {
            halt();
		}
	}
}

/**
* IRQ handler, call a hardware interrupt (for instance timer or keyboard)
* @param regs CPU context used when saving/restoring context from an interrupt
*/
void irq_handler(regs_t *regs) {
	irq_get_handler(regs->number)->func();
	pic_eoi(regs->number);
}

/**
* Init the IDT table
*/
void idt_init() {
    irq_init();

	idt_ptr.limit = sizeof(idt) - 1;
	idt_ptr.base  = (uint32_t)&idt;

	// Clear up all entries
	memsetb(idt, 0, sizeof(idt));

	// IDT entries 0-31: CPU exceptions.
	void (*exceptions[])(void) = {
		_exception0,_exception1,_exception2,_exception3,_exception4,
		_exception5,_exception6,_exception7,_exception8,_exception9,
		_exception10,_exception11,_exception12,_exception13,_exception14,
		_exception15,_exception16,_exception17,_exception18,_exception19,_exception20
	};
	for (int i = FIRST_EXCEPTION; i <= LAST_EXCEPTION; i++) {
		idt[i] = idt_build_entry(GDT_KERNEL_CODE_SELECTOR, (uint32_t)exceptions[i], TYPE_INTERRUPT_GATE, DPL_KERNEL);
	}

	// IDT entries 32-47: hardware interrupts.
	// Map the 16 hardware interrupts requests (IRQs). They are located at gates 32-47.
	// See 5.3.1 of Intel 64 & IA32 architectures software developer's manual for a list of these IRQs
	void (*irqs[])(void) = {
		// Timer (PIT) generates an IRQ0
		// Keyboard generates an IRQ1
		_irq0,_irq1,_irq2,_irq3,_irq4,_irq5,_irq6,_irq7,_irq8,_irq9,_irq10,_irq11,_irq12,_irq13,_irq14,_irq15
	};
	for (int i = IRQ_FIRST; i <= IRQ_LAST; i++) {
		idt[IRQ_REMAP_OFFSET+i] = idt_build_entry(GDT_KERNEL_CODE_SELECTOR, (uint32_t)irqs[i], TYPE_INTERRUPT_GATE, DPL_KERNEL);
	}
	
	idt[48] = idt_build_entry( GDT_KERNEL_CODE_SELECTOR ,( uint32_t ) & _syscall_handler , TYPE_TRAP_GATE, DPL_USER );

	idt_load(&idt_ptr);
}
