#ifndef _IDT_H_
#define _IDT_H_

#include "common/types.h"
#include "common/mem.h"
#include "drivers/keyboard.h"
#include "drivers/timer.h"
#include "drivers/pic.h"
#include "mem/gdt.h"
#include "irq.h"
#include "x86.h"
#include "descriptors.h"
#include "print/print.h"

#define INTERRUPT_COUNT   256

#define FIRST_EXCEPTION   0
#define LAST_EXCEPTION    20
#define EXCEPTION_COUNT   (LAST_EXCEPTION-FIRST_EXCEPTION+1)

#define IRQ_REMAP_OFFSET  32

// Structure of an IDT descriptor. There are 3 types of descriptors:
// task-gates, interrupt-gates, trap-gates.
// See 5.11 of Intel 64 & IA32 architectures software developer's manual for more details.
// For task gates, offset must be 0.
typedef struct idt_entry_st {
	uint16_t offset15_0;   // only used by trap and interrupt gates
	uint16_t selector;     // segment selector for trap and interrupt gates; TSS segment
                           // selector for task gates
	uint16_t reserved : 8;
	uint16_t type : 5;
	uint16_t dpl : 2;
	uint16_t p : 1;
	uint16_t offset31_16;  // only used by trap and interrupt gates
} __attribute__((packed)) idt_entry_t;

// CPU context used when saving/restoring context from an interrupt
typedef struct regs_st {
	uint32_t tss_selector;  // to know where we're coming from
	uint32_t gs, fs, es, ds;
	uint32_t ebp, edi, esi;
	uint32_t edx, ecx, ebx, eax;
	uint32_t number, error_code;
	uint32_t eip, cs, eflags, esp, ss;
} regs_t;

// Structure describing a pointer to the IDT gate table.
// This format is required by the lidt instruction.
typedef struct idt_ptr_st {
	uint16_t limit;   // Limit of the table (ie. its size)
	uint32_t base;    // Address of the first entry
} __attribute__((packed)) idt_ptr_t;

// Implemented in ../syscall/syscall_asm.s
extern void _syscall_handler();

// Defined in idt_asm.s
extern void idt_load(idt_ptr_t *idt_ptr);

// These are defined in idt_asm.s
extern void _exception0();
extern void _exception1();
extern void _exception2();
extern void _exception3();
extern void _exception4();
extern void _exception5();
extern void _exception6();
extern void _exception7();
extern void _exception8();
extern void _exception9();
extern void _exception10();
extern void _exception11();
extern void _exception12();
extern void _exception13();
extern void _exception14();
extern void _exception15();
extern void _exception16();
extern void _exception17();
extern void _exception18();
extern void _exception19();
extern void _exception20();

// These are defined in idt_asm.s
extern void _irq0();
extern void _irq1();
extern void _irq2();
extern void _irq3();
extern void _irq4();
extern void _irq5();
extern void _irq6();
extern void _irq7();
extern void _irq8();
extern void _irq9();
extern void _irq10();
extern void _irq11();
extern void _irq12();
extern void _irq13();
extern void _irq14();
extern void _irq15();

// Exception handler, display a fatal error message and stop the kernel
void exception_handler(regs_t *regs);
// IRQ handler, call a hardware interrupt (for instance timer or keyboard)
void irq_handler(regs_t *regs);
// Init the IDT table
void idt_init();

#endif
