/**
* @file paging.c
* @brief utilities for the paging using
* a PDE and some PTEs
*
* Memory mapping from a virtual address
* to a physical address and managing PDE / PTEs 
* 
* @author Dagier Thomas, Bernasconi Dorian
* @bug No known bugs.
* @date 24.01.2022
* @version 1.0
*/

#include "paging.h"

// object is static as we want to keep a global state of the PDE at any time
static pagetable_t kernel_pagedir[PAGETABLE_COUNT] __attribute__((aligned(PAGE_SIZE)));

/**
* Initialize paging, map the kernel addresses and the framebuffer
* @param kernel_size the size of the kernel in KB used to map addresses
*/
void init_paging(){
    multiboot_info_t *mbi = multiboot_get_info();

    uint8_t count = multiboot_get_module_count();
    init_frames_array((uint32_t)multiboot_get_module_final_addr(count), (uint32_t)mbi->mem_upper);

    map(0, 0, mbi->mem_upper / 4, PRIVILEGE_KERNEL, kernel_pagedir);
    uint32_t fb_size = (get_framebuffer_size() * (mbi->framebuffer_bpp / 8)) / PAGE_SIZE;
    map(mbi->framebuffer_addr, mbi->framebuffer_addr, fb_size, PRIVILEGE_KERNEL, kernel_pagedir);
    map(0x40000000, mbi->framebuffer_addr, fb_size, PRIVILEGE_KERNEL, kernel_pagedir);

    paging_load_pagedir((uint32_t) kernel_pagedir);
    paging_enable();
}

/**
* If there is no entry in the PDE matching with the given index, create a new one
* @param index_in_pde the index in the PDE get from the virtual address
*/
void update_pde(uint32_t index_in_pde, pagetable_t pagedir[PAGE_COUNT]){
    pagedir[index_in_pde].pagetable_base_addr = TO_ENTRY_ADDR(alloc_frame()) & 0xfffff;
    pagedir[index_in_pde].present = 1;
    pagedir[index_in_pde].rw = 1;
    pagedir[index_in_pde].user = PRIVILEGE_USER;
}

/**
* Update an entry in the PTE knowing his index, the privilege and the physical address
* @param crt_page the current page to update
* @param index_in_pte the index in the PTE get from the virtual address
* @param p enum(PRIVILEGE_KERNEL = 0, PRIVILEGE_USER = 1)
* @param p_addr the phyiscal address that should be insert in the current page
*/
void update_pte(page_t* crt_page, uint32_t index_in_pte, privilege_t p, uint32_t p_addr){
    crt_page[index_in_pte].page_base_addr = TO_ENTRY_ADDR(p_addr) & 0xfffff;
    crt_page[index_in_pte].present = 1;
    crt_page[index_in_pte].rw = 1;
    crt_page[index_in_pte].user = p;
}

/**
* Map a virtual address to a physical address using the PDE and the PTE 
*   They might be updated depending on the virtual address given
* @param v_addr the virtual address to map
* @param p_addr the phyiscal address that should be insert in the current page
* @param frame_count the number of frames to map
* @param p enum(PRIVILEGE_KERNEL = 0, PRIVILEGE_USER = 1)
*/
void map(uint32_t v_addr, uint32_t p_addr, uint32_t f_count, privilege_t p, pagetable_t pagedir[PAGE_COUNT]){
    for(uint32_t i = 0; i < f_count; i++){
        uint32_t index_in_pde = ADDR_TO_PAGETABLE(v_addr + (i << 12));
        uint32_t index_in_pte = ADDR_TO_PAGE(v_addr + (i << 12)) & 0x3FF;
        if(!pagedir[index_in_pde].present){
            update_pde(index_in_pde, pagedir);
        }
        page_t* current_page = (page_t*)(pagedir[index_in_pde].pagetable_base_addr << 12);
        update_pte(current_page, index_in_pte, p, p_addr + (i << 12));
    }
}

/**
* Return the kernel_pagedir
* @return the kernel_pagedir
*/
pagetable_t* get_kernel_pagedir(){
    return kernel_pagedir;
}