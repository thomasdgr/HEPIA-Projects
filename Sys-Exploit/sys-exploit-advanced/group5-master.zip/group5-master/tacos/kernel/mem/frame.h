#ifndef _FRAME_H_
#define _FRAME_H_

#include "common/types.h"
#include "paging.h"
#include "print/print.h"

// Our kernel only uses 4KB frames.
#define FRAME_SIZE 4096

// Max number of frames available in the physical memory
#define FRAME_COUNT 1048576 // exactly 4Gb / 4Kb

// the number of bits from an uint32_t used to index the frame_array
#define FRAME_ENTRY_SIZE 32

#define GET_X_COORD(x) (((uint32_t)x) % FRAME_ENTRY_SIZE)
#define GET_Y_COORD(y) (((uint32_t)y) / FRAME_ENTRY_SIZE)

// Initialize the array of frames with 0 (available) or 1 (unavailable)
// the frames that are available are those matching with the RAM except those used by the kernel
void init_frames_array(uint32_t last_module_addr, uint32_t max_ram_size);
// Take an address and return "true" if the corresponding frame is available, else "false"
bool check_frame_value(uint32_t addr);
// Take the index of a frame (suposed to be available) and mark it as use
void mark_frame_as_used(uint32_t index);
// Take the index of a frame (suposed to be unavailable) and mark it as free
void mark_frame_as_freed(uint32_t index);
// Return the address of the frist frame available and mark it as used
void* alloc_frame();
// From the coordinates of a frame, return the matching address (the first address of the frame)
void* get_addr_from_coordinates(uint8_t x, uint32_t y);
// From an address (of a frame that should be used), mark the matching frame as free 
void free_frame(void* addr);
// Return the address of the frist set of contiguous frames available and mark them as used
void* alloc(uint32_t size);
// From coordinates of the last frame, mark as used the "count" frames before 
// (including the current one) and return the address of the first frame of the set 
void* alloc_n_frames(uint8_t count, uint8_t x, uint32_t y);
// From an address (of a frame that should be used) and a number of frames, free the frames
void free(void* addr, uint32_t count);
#endif
