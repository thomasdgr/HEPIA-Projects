/**
* @file frame.c
* @brief utilities for the frame array used
* to manage physical memory
*
* Physical memory managment using a static array
* to know if a frame is available or not 
* 
* @author Dagier Thomas, Bernasconi Dorian
* @bug No known bugs.
* @date 24.01.2022
* @version 1.0
*/

#include "frame.h"

// object is static as we want to keep a global state of the array at any time
static uint32_t frames_array[FRAME_COUNT / FRAME_ENTRY_SIZE];

/**
* Initialize the array of frames with 0 (available) or 1 (unavailable)
*   the frames used for the kernel or outside the RAM are unavailavble
* @param last_module_addr the address of the last module loaded by grub 
* @param max_ram_size the amount of remaining memory
*/
void init_frames_array(uint32_t last_module_addr, uint32_t max_ram_size){
    // Convert the address to get the matching frame index 
    uint32_t end_kernel_frame_index = TO_ENTRY_ADDR(last_module_addr);
    // Knowing the frame index in the array, we need to know on wich uint32_t the frame is
    uint32_t y = GET_Y_COORD(end_kernel_frame_index);
    // Then we need to know on wich bit of the uint32_t the frame is
    uint8_t x = GET_X_COORD(end_kernel_frame_index);
    for(uint32_t i = 0; i < (FRAME_COUNT / FRAME_ENTRY_SIZE); i++){
        if(i >= y && i < (max_ram_size / 4)){
            frames_array[i] = 0;
            if(i == y){
                for(uint8_t j = 0; j <= x; j++){
                    frames_array[i] |= 1 << j;
                }
            }
        }else{
            frames_array[i] = 0xFFFFFFFF;
        }
    }
}

/**
* Take an address and return "true" if the corresponding frame is available, else "false"
* @param addr the address that match with a frame (that sould be free)
* @return "true" if the addr is matching with a used frame, else "false"
*/
bool check_frame_value(uint32_t addr){
    uint32_t bit_number = addr / FRAME_SIZE;
    uint32_t y = GET_Y_COORD(bit_number);
    uint8_t x = GET_X_COORD(bit_number);
    return frames_array[y] & (1 << x);
}

/**
* Take the index of a frame (suposed to be available) and mark it as used
* @param addr the address that match with a frame (that sould be free)
*/
void mark_frame_as_used(uint32_t addr){
    if(!check_frame_value(addr)){
        uint32_t bit_number = addr / FRAME_SIZE;
        uint32_t y = GET_Y_COORD(bit_number);
        uint8_t x = GET_X_COORD(bit_number);
        frames_array[y] |= 1 << x;
    }
}

/**
* Take the index of a frame (suposed to be unavailable) and mark it as freed
* @param addr the address that match with a frame (that sould be used)
*/
void mark_frame_as_freed(uint32_t addr){
    if(check_frame_value(addr)){
        uint32_t bit_number = addr / FRAME_SIZE;
        uint32_t y = GET_Y_COORD(bit_number);
        uint8_t x = GET_X_COORD(bit_number);
        frames_array[y] &= ~(1 << x);
    }
}

/**
* Return the address of the frist frame available and mark it as used
* @return the address of the first frame available
*/
void* alloc_frame(){
    for(uint32_t y = 0; y < (FRAME_COUNT / FRAME_ENTRY_SIZE); y++){
        if(frames_array[y] != 0xFFFFFFFF){
            // If at least a frame is free we look for it
            for(uint8_t x = 0; x < FRAME_ENTRY_SIZE; x++){
                if(!(frames_array[y] & 1 << x)){
                    void* addr = get_addr_from_coordinates(x,y);
                    mark_frame_as_used((uint32_t) addr);
                    return addr;
                }
            }
        }
    }
    // All frames are used
    return (void*) -1;
}

/**
* From the coordinates of a frame, return the first address of the matching frame
* @param x the position of the frame in the uint32_t element from the static array
* @param y the position of the uint32_t element from the static array
* @return the address of the matching frame described by its coordinates
*/
void* get_addr_from_coordinates(uint8_t x, uint32_t y){
    return (void*) (((y * FRAME_ENTRY_SIZE) + x) * FRAME_SIZE);
}

/**
* From an address (of a frame that should be used), mark the matching frame as free
* @param addr the address corresponding to a frame that should be used and set to free
*/
void free_frame(void* addr){
    mark_frame_as_freed((uint32_t) addr);
}

/**
* From an address (of a frame that should be used) and a number of frames, free the frames
* @param addr the address corresponding to a frame that should be used and set to free
* @param count the number of frames to free
*/
void free(void* addr, uint32_t count){
    for(uint32_t i = 0; i < count; i++){
        free_frame((void*)(addr + FRAME_SIZE*i));
    }
}

/**
* Return the address of the frist set of contiguous frames available and mark them as used
* @param number_frame the number of frame we want to allocate
* @return the address of the first frame of the set allocated
*/
void* alloc(uint32_t number_frame){
    uint8_t count = 0;
    for(uint32_t y = 0; y < (FRAME_COUNT / FRAME_ENTRY_SIZE); y++){
        if(frames_array[y] != 0xFFFFFFFF){
            for(uint8_t x = 0; x < FRAME_ENTRY_SIZE; x++){
                // A set of contiguous frame can be on differents uint32_t elements
                if(!(frames_array[y] & 1 << x)){
                    count++;
                    if(count == number_frame){
                        return alloc_n_frames(count, x, y);
                    }
                // Reset the counter if we found frames but not enough
                } else if(count > 0){
                    count = 0;
                }                    
            }
        }
    }
    // All frames are used or not enough available contiguously
    return (void*) -1; 
}

/**
* From coordinates of the last frame, mark as used the "count" frames before 
*   (including the current one) and return the address of the first frame of the set 
* @param count the number of frame we want to allocate
* @param x the position of the frame in the uint32_t element from the static array
* @param y the position of the uint32_t element from the static array
* @return the address of the first frame of the set allocated
*/
void* alloc_n_frames(uint8_t count, uint8_t x, uint32_t y){
    void* addr;
    for(; count > 0; count--, x--){
        addr = get_addr_from_coordinates(x,y);
        mark_frame_as_used((uint32_t) addr);
    }
    return addr;
}