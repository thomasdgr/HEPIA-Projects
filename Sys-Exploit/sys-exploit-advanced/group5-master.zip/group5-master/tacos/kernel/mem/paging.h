#ifndef _PAGING_H_
#define _PAGING_H_

#include "frame.h"

// Divide address by PAGE_SIZE (4096)
#define TO_ENTRY_ADDR(x) (((uint32_t)x) >> 12)

// The maximum number of pages in total on a IA-32 architecture is 2^20 (= 1048576 pages).
// 1048576 * 4096KB = 4GB

// The hardware supports 3 page sizes: 4KB, 4MB and 2MB (when PAE is enabled)
// Our kernel only uses 4KB pages.
#define PAGE_SIZE  4096

// Max number of pages in a page table
#define PAGE_COUNT 1024

// Max number of page tables in a page directory
#define PAGETABLE_COUNT 1024

// Return the index of the page table (in a page directory) for a given physical address
#define ADDR_TO_PAGETABLE(addr) ((addr) >> 22)

// Return the index of the page for a given physical address
#define ADDR_TO_PAGE(addr) ((addr) >> 12)

// Our kernel only uses 4KB frames.
#define FRAME_SIZE 4096

// Max number of frames available in the physical memory
#define FRAME_COUNT 1048576 // exactly 4Gb / 4Kb

// the number of bits from an uint32_t used to index the frame_array
#define FRAME_ENTRY_SIZE 32 

// For details about a page directories and a page tables, see Vol.3A System Programming Guide Part1
// of the Intel 64 and IA-32 Architecture Software Dev's Manual.
// In particular, section 3.7.6 Page-Directory and Page-Table Entries

typedef enum privilege_t {
    PRIVILEGE_KERNEL = 0,
    PRIVILEGE_USER = 1
} privilege_t;

// Structure of a page table (in other words, a page directory entry). A page directory is an
// array of page tables.
// A page table can hold 1024 pages which means addressing up to 4MB of RAM (using 4KB pages).
// Using 1024 page tables, we can address 4GB of RAM.
typedef struct {
	uint32_t present : 1;        // page table currently loaded in memory (used for swapping)
	uint32_t rw : 1;             // specifies read-write privileges
	uint32_t user : 1;           // specifies user or supervisor privilege
	uint32_t write_through : 1;  // enable/disable write-through caching for the associated
                                 // page table
	uint32_t cache_disable : 1;  // enable/disable caching of the associated page table
                                 // (useful for MMIO)
	uint32_t accessed : 1;       // page table has been accessed by read or write (set by cpu)
	uint32_t reserved : 1;       // reserved (0)
	uint32_t page_sz : 1;        // page size: 0 = 4KB, 1 = 4MB
	uint32_t gp : 1;             // indicates a global page (ignored)
	uint32_t available : 3;      // unused, freely available for kernel use
	uint32_t pagetable_base_addr : 20;  // physical address of the 1st byte of the page table
} __attribute__((packed)) pagetable_t;

// Structure of a page (in other words, a page table entry). A page table is an array of pages.
// A page can hold 2^12 bytes = 4096 bytes = 4KB.
typedef struct {
	uint32_t present : 1;        // page currently loaded in memory (used for swapping)
	uint32_t rw : 1;             // specifies read-write privileges
	uint32_t user : 1;           // specifies user or supervisor privilege
	uint32_t write_through : 1;  // enable/disable write-through caching for the associated page
	uint32_t cache_disable : 1;  // enable/disable caching of the associated page
                                 // (useful for MMIO)
	uint32_t accessed : 1;       // page has been accessed by read or write (set by cpu)
	uint32_t dirty : 1;          // page has been written to (set by cpu)
	uint32_t pat : 1;            // only used when using "Page Attribute Table" (PAT),
                                 // 0 otherwise
	uint32_t gp : 1;             // indicates a global page
	uint32_t available : 3;      // unused, freely available for kernel use
	uint32_t page_base_addr : 20;  // physical address of the 1st byte of the page
} __attribute__((packed)) page_t;

// Functions below are implemented in paging_asm.s
extern void paging_enable();
extern void paging_load_pagedir(uint32_t dir_entry_addr);
extern pagetable_t *paging_get_current_pagedir();

// Initialize paging, map the kernel addresses and the framebuffer
void init_paging();
// If there is no entry in the PDE matching with the given index, create a new one
void update_pde(uint32_t index_in_pde, pagetable_t pagedir[PAGE_COUNT]);
// Update an entry in the PTE knowing his index, the privilege and the physical address
void update_pte(page_t* crt_page, uint32_t index_in_pte, privilege_t p, uint32_t p_addr);
// Map a virtual address to a physical address using the PDE and the PTE 
// They might be updated depending on the virtual address given
void map(uint32_t v_addr, uint32_t p_addr, uint32_t frame_count, privilege_t p, pagetable_t pagedir[PAGE_COUNT]);
// Return the kernel_pagedir
pagetable_t* get_kernel_pagedir();

#endif
