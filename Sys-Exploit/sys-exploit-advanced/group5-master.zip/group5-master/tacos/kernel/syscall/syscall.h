#ifndef _SYSCALL_H_
#define _SYSCALL_H_

#include "common/syscall_nb.h"

//
extern int syscall_handler(syscall_t nb, uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4, uint32_t caller_tss_selector);

// Manage the puts (and putc) syscall 
int syscall_puts(uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4);
// Manage the exec syscall
int syscall_exec(uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4);
// Manage the getc syscall
int syscall_getc(uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4);
// Manage the file_stat syscall
int syscall_file_stat(uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4);
// Manage the file_read syscall
int syscall_file_read(uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4);
// Manage the sleep syscall
int syscall_sleep(uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4);

#endif