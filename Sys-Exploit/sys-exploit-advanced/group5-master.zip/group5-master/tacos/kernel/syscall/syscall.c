#include "common/types.h"
#include "syscall.h"
#include "print/print.h"
#include "drivers/keyboard.h"
#include "task/task.h"
#include "drivers/timer.h"

// array of functions managing all syscalls implemented
static int (*syscall_func[])(uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4) = {
    syscall_puts,
    syscall_exec,
    syscall_getc,
    syscall_file_stat,
    syscall_file_read,
    syscall_sleep,
};

/**
 * general handler of syscalls used to redirect any call to the matching function implemented
 */
int syscall_handler(syscall_t nb, uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4,
    uint32_t caller_tss_selector) {
    
    UNUSED(caller_tss_selector);
    if (nb < __SYSCALL_END__) {
        return syscall_func[nb](arg1, arg2, arg3, arg4);
    } else {
        return -1;
    };
}

/**
 * Manage the puts (and putc) syscall 
 */
int syscall_puts(uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4){
    UNUSED(arg2);
    UNUSED(arg3);
    UNUSED(arg4);
    char* ptr = (char*)(arg1);
    printf(ptr);
    return 0;
}

/**
 * Manage the exec syscall
 */
int syscall_exec(uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4){
    UNUSED(arg2);
    UNUSED(arg3);
    UNUSED(arg4);
    char* ptr = (char* )(arg1);
    exec_task(ptr);
    return 0;
}

/**
 * Manage the getc syscall
 */
int syscall_getc(uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4){
    UNUSED(arg1);
    UNUSED(arg2);
    UNUSED(arg3);
    UNUSED(arg4);
    return keyb_get_key();
}

/**
 * Manage the file_stat syscall
 */
int syscall_file_stat(uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4){
    UNUSED(arg3);
    UNUSED(arg4);
    stat_t *stat = (stat_t*)arg2;
    int index = get_module_index(((char*)arg1));
    if(index < 0){
        printf("file %s not found", (char*)arg1);
        return -1;
    }
    uint32_t size = multiboot_get_module_size(index);
    if(size > 0){
        stat->size = size;
        return 0;
    }
    return -1;
    
}

/**
 * Manage the file_read syscall
 */
int syscall_file_read(uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4){
    UNUSED(arg2);
    UNUSED(arg3);
    UNUSED(arg4);
    int index = get_module_index(((char*)arg1));
    if(index < 0){
        printf("file %s not found", (char*)arg1);
        return -1;
    }
    uint32_t size = multiboot_get_module_size(index);
    if(size > 0){
        for(uint32_t i = 0; i < size; i++){
            ((uint8_t*)arg2)[i] = ((uint8_t*)multiboot_get_module_addr(index))[i]; 
        }
        return 0;
    }
    return -1;
}

/**
 * Manage the sleep syscall
 */
int syscall_sleep(uint32_t arg1, uint32_t arg2, uint32_t arg3, uint32_t arg4){
    UNUSED(arg2);
    UNUSED(arg3);
    UNUSED(arg4);
    timer_sleep(arg1);
    return 0;
}