/**
* @file kernel.c
* @brief Kernel initialisation (part 1.)
*
* Currently init display, memory and I/O.
* Display the logo and the info from the kernel
*
* @author Dagier Thomas, Bernasconi Dorian
* @bug No known bugs.
* @date 04.02.2022
* @version 1.0
*/

#include "x86.h"
#include "tests/tests.h"
#include "interrupt/idt.h"
#include "task/task.h"

// These are defined in the linker script: kernel.ld
extern void ld_kernel_start();
extern void ld_kernel_end();
uint_t kernel_start = (uint_t)&ld_kernel_start;
uint_t kernel_end = (uint_t)&ld_kernel_end;

/**
* Display the logo given as a module in grub.cfg
* @param index_module the index of the module refering to the rgba image
*/
void init_logo(uint8_t index_module){
    char* cmd = multiboot_get_cmd(index_module);
    uint8_t argc = get_number_of_args_from_cmd(cmd, ' ');
    char* ptr[argc];
    parse_cmd(cmd, ptr);
    display_image((char**) &ptr, 400, 0, index_module);
}

/**
* Display the kernel info from the multiboot structure
*/
void display_kernel_info(){
    multiboot_info_t *mbi = multiboot_get_info();
    printf("|-----------------------------------|\n");
    printf("| RAM Available: %d KB          |\n", (mbi->mem_upper - mbi->mem_lower));
    printf("| Resolution: %d x %d             |\n",mbi->framebuffer_width,mbi->framebuffer_height);
    printf("| Bits per pixel: %d                |\n", mbi->framebuffer_bpp);
    printf("| pitch: %d                       |\n", mbi->framebuffer_pitch);
    printf("| framebuffer addr: 0x%x      |\n", mbi->framebuffer_addr);
    printf("| kernel addr :0x%x             |\n", kernel_start);
    printf("| kernel size : %d KB             |\n", (kernel_end - kernel_start) / 1024);
    printf("| module count: %d                   |\n", multiboot_get_module_count());
    printf("| module informations are hidden... |\n");    
    /*for(uint8_t i = 0; i < multiboot_get_module_count(); i++){
        printf("| module %d:                         |\n", i+1);
        printf("|   addr: 0x%x                  |\n", multiboot_get_module_addr(i));
        printf("|   size: %d KB                    |\n", multiboot_get_module_size(i) / 1024);
        printf("|   cmd : %s                   |\n", multiboot_get_cmd(i));
    }*/
    printf("|-----------------------------------|\n");
}

/**
* Program's entry point.
* @param mbi structure containing all the info from the kernel.
*/
void kernel_main(multiboot_info_t *mbi){
    multiboot_set_info(mbi);
    gdt_init();
    task_setup_initial_tss();
    init_paging();
    idt_init();
    pic_init();
    timer_init(50);
    sti();
    keyb_init();
    init_display(LIGHT_BLUE, WHITE);
    display_kernel_info();
    // change the index if logo is not the first module to be load
    init_logo(0);

    // testing all parts
    // printf("\n");
    // test_display();
    // test_fram_alloc_and_free();
    // test_paging(0x40000000);
    // test_timer();
    test_task();

    exec_task("shell");

    halt();
}