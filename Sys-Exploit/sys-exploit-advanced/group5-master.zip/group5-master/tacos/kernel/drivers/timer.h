#ifndef _TIMER_H_
#define _TIMER_H_

#define PIT_COMMAND 0x43

// We only use channel 0 here but 3 are available
#define PIT_CANAL_0 0x40

#define PIT_REPEAT_MODE 0x36

#define PIT_MIN_FREQUENCY 19       // Rounded 18.206512 Hz
#define PIT_MAX_FREQUENCY 1193182  // Exactly 1193182 MHz

// Initialize the timer with a specified frequency and install the timer handler
extern void timer_init(uint32_t freq_hz);
// Fuction used to get the current number of ticks since the timer was initialized
extern uint_t timer_get_ticks();
// Active wait for a given time, no matter the frequency, the time elapsed should be the same
extern void timer_sleep(uint_t ms);
// Fuction used to get frequency of the timer
extern uint_t timer_get_freq();
// Timer interrupt handler
void timer_handler();

#endif
