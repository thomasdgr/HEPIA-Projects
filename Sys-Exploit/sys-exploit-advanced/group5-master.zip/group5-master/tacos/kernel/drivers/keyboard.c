/**
* @file keyboard.c
* @brief Keyboard handling
*
* Initialize the Keyboard and managing the interrupt as
*   a known key is pressed 
*
* @author Dagier Thomas, Bernasconi Dorian
* @bug No known bugs.
* @date 04.02.2022
* @version 1.0
*/

#include "keyboard.h"

static uint32_t buffer[BUFFER_SIZE] = {};
static uint32_t buffer_count = 0;
static uint32_t buffer_write = 0;
static uint32_t buffer_read = 0;
static bool shift = false;

// we can replace some 0 by �
static char qwert_map_shift[] = {
	0,0,'+','"','*',0,'%','&','/','(',')','=','?','`',0,
	0,'Q','W','E','R','T','Z','U','I','O','P',0,'!','\n',
	0,'A','S','D','F','G','H','J','K','L',0,0,0,0,0,
	'Y','X','C','V','B','N','M',';',':','_',0,0,0,' ',
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,224,0,0,225,0,226,0,0,227
};

static char qwert_map[] = {
	0,27,'1','2','3','4','5','6','7','8','9','0','\'','^','\b',
	9,'q','w','e','r','t','z','u','i','o','p',0,'?','\n',
	17,'a','s','d','f','g','h','j','k','l',0,0,'?',6,'$',
	'y','x','c','v','b','n','m',',','.','-',7,0,18,' ',
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,224,0,0,225,0,226,0,0,227
};


/**
* Keyboard interrupt handler
*/
void keyb_handler(){
	if(check_key_pressed()){
		if(!check_buffer_full()){
            uint8_t key = inb(KEYB_DATA);
            if(!(key >> 7)){ // the bit 7 is at 0 so the key is pressed
                if(check_shift_pressed(key)){
                    shift = true;
                    return;
                }
                buffer_count++;
                buffer[buffer_write] = shift ? qwert_map_shift[key] : qwert_map[key];
                buffer_write = (buffer_write + 1) % BUFFER_SIZE;
            } else{ // the bit 7 is at 1 so the key is released
                key &= ~(1 << 7); // the bit 7 is set to 0 so we can shift
                if(check_shift_pressed(key)){
                    shift = false;
                }
			}
		} else{
            printf("Keyboard buffer full\n");
			return;
        }
	}
}

/**
* Initialize the keyboard
*/
void keyb_init(){
	handler_t handler = { keyb_handler, "keyboard" };
	irq_install_handler(1, handler);
}

/**
* Return the key that was pressed or 0 if no key is present in the internal buffer.
  This function never blocks.
*/
int keyb_get_key(){
	if(buffer_count != 0){
		buffer_count--;
		uint8_t pos = buffer_read;
		buffer_read = (buffer_read + 1) % BUFFER_SIZE;
		return buffer[pos];
	}
	return 0;
}

/**
* Check if any key is pressed
*/
bool check_key_pressed(){
    return inb(KEYB_STATE) & 0x1;
}

/**
* Check if buffer of char is full
*/
bool check_buffer_full(){
    return buffer_count == BUFFER_SIZE;
}

/**
* Check if key pressed is 'left_shift' or 'right_shift'
*/
bool check_shift_pressed(uint8_t key){
    return qwert_map[key] == 6 || qwert_map[key] == 7;
}