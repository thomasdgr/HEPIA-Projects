#ifndef _KEYBOARD_H_
#define _KEYBOARD_H_

#include "common/types.h"
#include "interrupt/irq.h"
#include "print/print.h"
#include "pmio.h"

#define KEYB_DATA     	0x60
#define KEYB_STATE    	0x64

#define BUFFER_SIZE 20

// Keyboard interrupt handler
extern void keyb_init();
// Initialize the keyboard
extern int keyb_get_key();
// Return the key that was pressed or 0 if no key is present in the internal buffer.
void keyb_handler();
// Check if any key is pressed
bool check_key_pressed();
// Check if buffer of char is full
bool check_buffer_full();
// Check if key pressed is 'left_shift' or 'right_shift'
bool check_shift_pressed(uint8_t key);

#endif
