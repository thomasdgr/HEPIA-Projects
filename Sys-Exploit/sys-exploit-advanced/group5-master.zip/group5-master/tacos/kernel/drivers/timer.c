/**
* @file timer.c
* @brief Timer handling
*
* Initialize the Timer and managing his ticks and frequency
*   using an interrupt handler
*
* @author Dagier Thomas, Bernasconi Dorian
* @bug No known bugs.
* @date 04.02.2022
* @version 1.0
*/

#include "common/types.h"
#include "timer.h"
#include "interrupt/irq.h"
#include "pmio.h"

// We want to make sure ticks is never cached when being read.
// Also we don't want the compiler to optimize its access with -O3.
static volatile uint_t ticks = 0; // Current ticks count

static volatile uint_t frequency = 0; // Current timer frequency

/**
* Timer interrupt handler
*/
void timer_handler(){
	ticks++;
}

/**
* Initialize the timer with a specified frequency and install the timer handler
* @param freq_hz the frequency given for the timer
*/
void timer_init(uint32_t freq_hz){
	ticks = 0;
	frequency = freq_hz;
	frequency = (freq_hz < PIT_MIN_FREQUENCY) ? PIT_MIN_FREQUENCY : frequency;
	frequency = (freq_hz > PIT_MAX_FREQUENCY) ? PIT_MAX_FREQUENCY : frequency;
	uint16_t divider = PIT_MAX_FREQUENCY / frequency;
	outb(PIT_COMMAND, PIT_REPEAT_MODE);
	outb(PIT_CANAL_0, (divider & 0xFF));
	outb(PIT_CANAL_0, (divider >> 8));
	handler_t handler = { timer_handler, "timer" };
	irq_install_handler(0, handler);
}

/**
* Active wait for a given time, no matter the frequency, the time elapsed should be the same
* @param ms the time in milliseconds to wait
*/
void timer_sleep(uint_t ms){
	for(ticks = 0; timer_get_ticks() < ms * frequency / 1000;){}
}

/**
* Fuction used to get the current number of ticks since the timer was initialized
* @return the total number of ticks
*/
uint_t timer_get_ticks(){
	return ticks;
}

/**
* Fuction used to get frequency of the timer
* @return the frequency
*/
uint_t timer_get_freq(){
	return frequency;
}