#include "ulibc.h"

#define TAB_SIZE  4
#define BUFF_SIZE 512

/**
* putc system call
* @param c the char to print
* @return -1 if failed, 0 else
*/
int putc(char c){
    return puts(&c);
}

/**
* puts system call
* @param str the string to print
* @return -1 if failed, 0 else
*/
int puts(char* str){
    return syscall(SYSCALL_puts,(uint32_t)str,NULL,NULL,NULL);
}

/**
* file_read system call
* @param filename the name of the file to read
* @param buf the buffer used to store content read
* @return -1 if failed, 0 else
*/
int file_read(char *filename, void *buf){
	return syscall(SYSCALL_file_read,(uint32_t)filename,(uint32_t)buf,NULL,NULL);
}

/**
* file_stat system call
* @param filename the name of the file to stat
* @param stat the structure used to store content stat
* @return -1 if failed, 0 else
*/
int file_stat(char *filename, stat_t *stat){
	return syscall(SYSCALL_file_stat,(uint32_t)filename,(uint32_t)stat,NULL,NULL);
}

/**
* exec system call
* @param filename the name of the file to exec
* @return -1 if failed, 0 else
*/
int exec(char *filename){
    return syscall(SYSCALL_exec,(uint32_t)filename,NULL,NULL,NULL);
}

/**
* exit system call
*/
void exit(){
    asm("iret");
}

/**
* getc system call
* @return -1 if failed, 0 else
*/
int getc(){
    return syscall(SYSCALL_getc,NULL,NULL,NULL,NULL); 
}

/**
* sleep system call
* @param ms the time in milliseconds to wait
* @return -1 if failed, 0 else
*/
int sleep(uint32_t ms){
	return syscall(SYSCALL_sleep,ms,NULL,NULL,NULL);
}

/**
* printf implementation for user
* @param txt the arguments given to print
*/
void printf(char* txt,...){
	va_list args;
    va_start(args, txt);
    char buf[BUFF_SIZE] = "";
    sprintf(buf, txt, args);
	va_end(args);
	puts((char*)buf);
}

/**
* Check if the given string start with the other given string
* @param cmd the string we want to search for
* @param line the string used to search for cmd at the begining
* @return true if the cmd is at the begining of line, else, false
*/
bool starts_with(char* cmd, char* line){
	char tmp[BUFF_SIZE] = "";
	strncpy(tmp , line, BUFF_SIZE);
	return strcmp(cmd, strtok(tmp, " ")) == 0;
}

/**
* Function used to display the text in the shell correctly
* @param buf the current string
*/
void read_string(char *buf) {
	char *start = buf;
	for (;;) {
		int c = getc();
		if (c) {
			if(c == '\b'){
				if (buf - start > 0) {
					putc(c);
					buf--;
				}
			} else if (c == '\n') {
				break;
			} else if (c == '\t') {
				c = ' ';
				for (int i = 0; i < 4; i++) {
					putc(c);
					*buf = c;
					buf++;
				}
			} else {
				printf("%c",c);
				*buf = c;
				buf++;
			}
		}
	}
	*buf = 0;
}