#include "ulibc.h"

/**
* Cat unix function implemented with our syscalls 
* @param filename the name of the file to cat 
*/
static void cat(char *filename) {
    stat_t size = {0};
    if(file_stat(filename,&size) > -1){
		char buf[512];
		if(file_read(filename, &buf) > -1){
			for(uint32_t i = 0; i < size.size; i++){
				printf("%c", buf[i]);
			}
		}
	}
}

/**
* Display command available in our shell
*/
static void help() {
	char msg[] = "\n\
	PROG      : execute program PROG\n\
	cat FILE  : dump contents of FILE\n\
	exec FILE  : execute FILE\n\
	exit      : exit this shell\n\
	help      : display this help\n\
	sleep N   : sleep for N milliseconds (preemptive)\n";
	puts(msg);
}

/**
* Tiny shell program
*/
void main(){
	puts("Welcome to TacO'shell! Type \"help\" for a list of commands.\n");
	char buf[512];
	while (1) {
		puts(">");
		read_string(buf);
		char *line = tolower(trim(buf));
		if (line[0] == 0) {
			printf("\n");
			continue;
		} else if (starts_with("cat", line)) {
			printf("\n");
			cat(trim(line + strlen("cat ")));
			printf("\n");
		} else if (starts_with("exec", line)) {
			printf("\n");
			exec(trim(line + strlen("exec ")));
			printf("\n");
		} else if (strcmp("help", line) == 0) {
			help();
		} else if (starts_with("sleep", line)) {
			uint_t ms = atoi(trim(line + strlen("sleep ")));
			printf("\n");
			printf("Sleeping for %dms...\n", ms);
			sleep(ms);
		} else if (strcmp("exit", line) == 0) {
			puts("\nLeaving TacOS...\n");
			exit();
		} else {
			printf("\n");
			printf("Command \"%s\" not found\n", line);
		}
	}
}