#include "ulibc.h"

/**
* Display the beautifull french flag
*/
void test_drawing(){
    printf("- test draw the most beautiful flag: \n");
    uint32_t fb = 0xC0000000;
	for(uint32_t i = 300; i < 325; i++){
        for(uint32_t j = 135; j < 185; j++){
            ((uint16_t*) fb)[j * 640 + i] = 0x000f;
            ((uint16_t*) fb)[j * 640 + i+25] = 0xffff;
            ((uint16_t*) fb)[j * 640 + i+50] = 0xf000;
        }
    }
}

/**
* Catch a char and print it
*/
void test_getc(){
    printf("- test getc: press a key... ");
    char c = 0;
    while(c == 0){
        c = getc();
        if(c != 0){
            printf("you pressed \'%c\'\n", c);
        }
    }
}

/**
* Execute a nested task loaded in grub too
* @param cmd the name of the task to execute
*/
void test_exec(char* cmd){
    printf("- test exec: Calling nested task %s...\n", cmd);
    exec(cmd);
}

/**
* basic unix cat function
* @param filename the name of the file to cat
*/
void test_cat(char* filename){
    printf("- test cat:\n");
    stat_t size = {0};
    file_stat(filename,&size);

    char buf[512];
    file_read(filename, &buf);
    for(uint32_t i = 0; i < size.size; i++){
        printf("%c", buf[i]);
    }
    printf("\n");
}

/**
* Timer sleep for a specific time
* @param ms the time in milliseconds to sleep
*/
void test_sleep(int ms){
    printf("- test sleep for %d ms: ", ms);
    sleep(ms);
    printf("OK\n");
}

/**
* The test program
*/
void main() {
    test_drawing();
    test_getc();
    test_sleep(2000);
    test_exec("test2");
    sleep(1500);
    test_cat("test.txt");
    printf("\n");
    exit();
    printf("should never be display!\n"); // as we exit the task
}