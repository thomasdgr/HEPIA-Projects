#include "ulibc.h"

/**
* The test program
*/
int main() {
    printf("Hello from task 2! : ");
    return 10 / 0;
}