#ifndef _ULIBC_H_
#define _ULIBC_H_

#include "common/types.h"
#include "common/stdio.h"
#include "common/string.h"
#include "common/mem.h"
#include "common/syscall_nb.h"
#include "syscall.h"

extern char *trim(char *line);
extern void read_string(char *buf);

// putc system call
int putc(char c);
// puts system call
int puts(char* str);
// file_read system call
int file_read(char *filename, void *buf);
// file_stat system call
int file_stat(char *filename, stat_t *stat);
// exec system call
int exec(char *filename);
// getc system call
int getc();
// sleep system call
int sleep(uint32_t ms);
// exit system call
void exit();
// printf implementation for user
void printf(char* txt,...);
// Check if the given string start with the other given string
bool starts_with(char* cmd, char* line);
// Function used to display the text in the shell correctly
void read_string(char *buf);

#endif