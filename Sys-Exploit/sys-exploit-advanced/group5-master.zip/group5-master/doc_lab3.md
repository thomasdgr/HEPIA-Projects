## Thomas Dagier et Dorian Bernasconi

# Labo 3: Tâches utilisateur et Appels systèmes


## Fonctionalités implémentées

 - A notre connaissance, tout fonctionne 

## Fonctionalités implémentées mais non-terminées

 - Normalement tout fonctionne 

## Fonctionalités non-terminées

 - Normalement tout fonctionne 
