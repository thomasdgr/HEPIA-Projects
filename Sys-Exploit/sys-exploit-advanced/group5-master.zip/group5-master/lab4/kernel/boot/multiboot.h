#ifndef _MULTIBOOT_H_
#define _MULTIBOOT_H_

#include "common/types.h"
#include "multiboot_structs.h"

extern multiboot_info_t* multiboot_get_info();
extern void multiboot_set_info(multiboot_info_t *_mbi);
extern uint_t multiboot_get_RAM_in_KB();

#endif
