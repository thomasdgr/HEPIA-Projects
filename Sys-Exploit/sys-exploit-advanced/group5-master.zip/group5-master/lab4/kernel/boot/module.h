#ifndef _MODULE_H_
#define _MODULE_H_

#include "common/types.h"
#include "boot/multiboot.h"

extern uint_t module_get_count();
extern void *module_get_address(uint_t module_index);
extern uint_t module_get_size(uint_t index);
extern char* module_get_cmdline(uint_t index);
extern uint32_t module_get_last_address();
extern void module_display_info();

#if 0
void module_remap_contents(multiboot_info_t *mbi, uint_t module_idx, void *dest);
#endif

#endif
