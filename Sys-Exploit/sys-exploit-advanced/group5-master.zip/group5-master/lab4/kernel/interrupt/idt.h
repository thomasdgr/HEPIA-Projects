#ifndef _IDT_H_
#define _IDT_H_

extern void idt_init();

#endif
