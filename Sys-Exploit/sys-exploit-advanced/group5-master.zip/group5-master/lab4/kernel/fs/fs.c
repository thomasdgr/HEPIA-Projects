/**
* @file fs.c
* @brief utilities for the file system used by the kernel
*
* Functions to stat, open, read, seek, and close files.
* using superblock and inode structures with iterators.
* 
* @author Dagier Thomas, Bernasconi Dorian
* @bug No known bugs.
* @date 17.04.2022
* @version 1.0
*/

#include "fs.h"

superblock_t* sb;
bitmap_t inodes_bitmap;
bitmap_t blocks_bitmap;
inode_table_t inodes_table;
fd_t file_descriptors[FILE_DESCRIPTOR_MAX_COUNT];

/**
* Initialize the file system.
*/
void fs_init(){
    read_sector(0, sb, SECTOR_SIZE);
    for(uint32_t i = 0; i < FILE_DESCRIPTOR_MAX_COUNT; i++){
		file_descriptors[i].is_free = true;
	}
    inodes_bitmap.count = sb->inode_count;
    inodes_bitmap.size = ROUND_UP(sb->inode_count, sizeof(inodes_bitmap.size));
    inodes_bitmap.bits = frames_alloc(ROUND_UP(sb->inode_bitmap_block_count * sb->block_size, FRAME_SIZE));
    for(int i = 0; i < ROUND_UP(inodes_bitmap.size, SECTOR_SIZE); i++){
        read_sector(get_sector_size(sb->inode_bitmap_start) + i, inodes_bitmap.bits + SECTOR_SIZE * i, SECTOR_SIZE);
    }
    blocks_bitmap.count = sb->datablock_count;
    blocks_bitmap.size = ROUND_UP(sb->datablock_count, sizeof(blocks_bitmap.size));
    blocks_bitmap.bits = frames_alloc(ROUND_UP(sb->datablock_bitmap_block_count * sb->block_size, FRAME_SIZE));
    for(int i = 0; i < ROUND_UP(blocks_bitmap.size, SECTOR_SIZE); i++){
        read_sector(get_sector_size(sb->datablock_bitmap_start) + i, blocks_bitmap.bits + SECTOR_SIZE * i, SECTOR_SIZE);
    }
    inodes_table.inode_count = sb->inode_count;
    inodes_table.size = sb->inode_block_count * sb->block_size;
    inodes_table.inodes = frames_alloc(ROUND_UP(inodes_table.size, FRAME_SIZE));
    for(int i = 0; i < ROUND_UP(inodes_table.size, SECTOR_SIZE); i++){
        read_sector(get_sector_size(sb->inode_start) + i, inodes_table.inodes + SECTOR_SIZE * i, SECTOR_SIZE);
    }
}

/**
 * State the file and store the data in the structure given.
 * @param filename The name of the file.
 * @param stat The structure to store the data in.
 * @return 0 on success, -1 on failure.
 */
int file_stat(const char *filename, stat_t *stat){
    inode_t* i = inode_get_from_filename(&inodes_table, filename);
    if(i != NULL){
        *stat = (stat_t){i->size, i->number};
        return 0;
    }
    return -1;
}

/**
 * Open a file.
 * @param filename The name of the file.
 * @return The file descriptor of the file, -1 on failure. 
 */
int file_open(const char *filename){
    inode_t* i = inode_get_from_filename(&inodes_table, filename);
    if(i != NULL){
        int index = get_first_fd_available();
        if(index != -1){
            file_descriptors[index] = (fd_t){false, 0, i};
            return index;
        }
    }
    return -1;
}

/**
 * Read data from a file.
 * @param fd The file descriptor of the file.
 * @param buf The buffer to store the data in.
 * @param count The number of bytes to read.
 * @return The number of bytes read, -1 on failure.
 */
int file_read(int fd, void *buf, uint_t count){
    if(fd < 0 || fd >= FILE_DESCRIPTOR_MAX_COUNT || file_descriptors[fd].is_free){
        return -1;
    }
    uint32_t bytes_read = 0;
    uint32_t external_offset = file_descriptors[fd].crt_offset / sb->block_size;
    uint32_t internal_offset = file_descriptors[fd].crt_offset % sb->block_size;
    // copy data from the blocks pointed by the direct pointers to the given buffer
    for(uint32_t i = external_offset; i < INODE_DIRECT_PTR_CNT && count > 0; i++){
        uint32_t sector_index = get_sector_size(file_descriptors[fd].crt_inode->direct_ptr[i] + sb->datablocks_start);
        bytes_read = read_data(fd, buf, bytes_read, sector_index, &count, &internal_offset);
    }
    // copy data from the blocks pointed by the indirect pointers to the given buffer
    for(uint32_t i = 0; i < INODE_INDIRECT_PTR_CNT && count > 0; i++){
        // create an array of direct pointers using the indirect pointer
        uint16_t direct_ptr[SECTOR_SIZE];
        uint32_t sector_index = get_sector_size(file_descriptors[fd].crt_inode->indirect_ptr[i] + sb->datablocks_start);
        read_block(sector_index, (void*)direct_ptr, SECTOR_SIZE);
        // copy data from the blocks pointed by the new direct pointers to the given buffer
        for(uint32_t j = 0; j < SECTOR_SIZE && count > 0; j++){
            // we make sure the direct pointer is valid
            if((i * SECTOR_SIZE) + j + INODE_DIRECT_PTR_CNT >= external_offset){
                uint32_t sector_index = get_sector_size(direct_ptr[j] + sb->datablocks_start);
                bytes_read = read_data(fd, buf, bytes_read, sector_index, &count, &internal_offset);
            }
        }
    }
    file_descriptors[fd].crt_offset += bytes_read;
    return bytes_read;
}

/**
 * Seek in a file at a specific position and update the corresponding offset.
 * @param fd The file descriptor of the file.
 * @param offset The offset to seek into.
 * @return 0 on success, -1 on failure.
 */
int file_seek(int fd, uint_t offset){
    if(fd >= 0 && fd < (int)sb->inode_count && file_descriptors[fd].is_free == false){
        if(offset > file_descriptors[fd].crt_inode->size){
            return -1;
        }
        file_descriptors[fd].crt_offset = offset;
    }
    return 0;
}

/**
 * Close a file.
 * @param fd The file descriptor of the file.
 */
void file_close(int fd){
    if(fd >= 0 && fd < (int)sb->inode_count && file_descriptors[fd].is_free == false){
		file_descriptors[fd].is_free = true;
    }
}

/**
 * Create an empty iterator for the file system 
 * @return the iterator created 
 */
file_iterator_t file_iterator(){
    return (file_iterator_t){0};
}

/**
 * Check if there is a next file in the iterator
 * @param it The iterator to check
 * @return true if there is a next file, else, false 
 */
bool file_has_next(file_iterator_t *it){
    for(uint32_t i = it->val+1; i < sb->inode_count; i++){
        if(bitmap_get(&inodes_bitmap, i)){
            return true;
        }
    }
	return false;
}

/**
 * Update the iterator and get the next entry matching with the current file given
 * @param filename The name of the file to jump at in the iterator
 * @param it The iterator to check
 */
void file_next(const char *filename, file_iterator_t *it){
    for(uint32_t i = it->val+1; i < sb->inode_count; i++){
        if(bitmap_get(&inodes_bitmap, i) == 1){
            memcpyb((char*)filename, inode_get_from_inode(&inodes_table, i)->name, INODE_FILENAME_LENGTH);
            it->val = i;
            return;
        }
    }
}

/**
 * Get the sector size object from the block size given
 * @param block The block to get the sector size from
 * @return The sector size 
 */
uint32_t get_sector_size(uint32_t block){
    return block * (sb->block_size / SECTOR_SIZE);
}

/**
 * Get the first available fd in the file descriptor table
 * @return The first fd available, -1 if there is no more space
 */
int get_first_fd_available(){
    for(uint32_t i = 0; i < sb->inode_count; i++){
        if(file_descriptors[i].is_free){
            return i;
        }
    }
    return -1;
}

/**
 * Read a sector and store its data in dst given
 * @param sector The sector to read 
 * @param dst The destination to store the data in 
 * @param size The size of the data to read (should be less than or equal to the sector size) 
 */
void read_sector(int sector, void* dst, int size){
    uint8_t buf[SECTOR_SIZE];
    ide_read_sector(sector, buf);
    memcpyb(dst, buf, size);
}

/**
 * Read a block and store its data in dst given
 * @param sector The sector to read 
 * @param dst The destination to store the data in 
 * @param size The size of the data to read
 */
void read_block(int sector, void* dst, int size){
    read_sector(sector, dst, size);
    read_sector(sector + 1, dst + SECTOR_SIZE, size);
}

/**
 * Sub-function from the read function
 * Given a file descriptor and a buffer, read the data from the given sector and store it in the buffer
 * @param fd The file descriptor of the file to read
 * @param dst The buffer to store the data in
 * @param crt_count The number of bytes that have already been read
 * @param sector_index The sector index to read from
 * @param tot_count The total number of bytes that need to be read
 * @param first_index True if this is the first read of the file, else, false
 * @return The number of bytes that has been read this time
 */
int read_data(int fd, void* dst, uint32_t crt_count, int sector_index, uint32_t* tot_count, uint32_t *internal_offset){
    // compute the number of bytes to read
    uint32_t bytes_read = *tot_count > sb->block_size - *internal_offset ? sb->block_size - *internal_offset : *tot_count;
    // we make sure that the amount of bytes to read will not be greater than the remaining bytes in the file
    if(file_descriptors[fd].crt_offset + crt_count + bytes_read > file_descriptors[fd].crt_inode->size){
        bytes_read = file_descriptors[fd].crt_inode->size - crt_count - file_descriptors[fd].crt_offset;
        *tot_count = 0;
    }
    // copy the data from the block to the buffer temporary as we may need to skip some bytes depending on the internal offset
    uint8_t buf_tmp[sb->block_size];
    read_block(sector_index, (void*)buf_tmp, SECTOR_SIZE);
    memcpyb(dst + crt_count, buf_tmp + *internal_offset, bytes_read);
    // the internal offset should be only used for the first read
    *internal_offset = 0;
    // update the number of bytes that we still have to read
    *tot_count = (*tot_count - bytes_read > 0) ? *tot_count - bytes_read : 0;
    return crt_count + bytes_read;
}