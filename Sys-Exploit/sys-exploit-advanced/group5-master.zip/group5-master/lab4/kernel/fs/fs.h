#ifndef _FS_H_
#define _FS_H_

#include "common/types.h"
#include "common/file.h"
#include "common/fs/fs.h"
#include "common/string.h"
#include "common/mem.h"
#include "common/fs/superblock.h"
#include "common/fs/inode.h"
#include "drivers/ide.h"
#include "drivers/term.h"
#include "mem/frame.h"

#define SECTOR_SIZE 512
#define INODE_MAX_COUNT 100
#define ENTRY_NAME_SIZE 128
#define FILE_DESCRIPTOR_MAX_COUNT 16

typedef struct fd_st {
    bool is_free;
    uint32_t crt_offset;
    inode_t* crt_inode;
} fd_t;

extern void fs_init();

extern int file_stat(const char *filename, stat_t *stat);
extern int file_open(const char *filename);
extern int file_read(int fd, void *buf, uint_t count);
extern int file_seek(int fd, uint_t offset);
extern void file_close(int fd);

extern file_iterator_t file_iterator();
extern bool file_has_next(file_iterator_t *it);
extern void file_next(const char *filename, file_iterator_t *it);

uint32_t get_sector_size(uint32_t block);
int get_first_fd_available();
void read_sector(int sector, void* dst, int size);
void read_block(int sector, void* dst, int size);
int read_data(int fd, void* dst, uint32_t count, int block_index, uint32_t* bytes_left, uint32_t* internal_offset);

#endif