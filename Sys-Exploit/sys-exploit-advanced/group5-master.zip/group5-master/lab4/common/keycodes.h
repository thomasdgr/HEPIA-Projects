#ifndef _KEYCODES_COMMON_H_
#define _KEYCODES_COMMON_H_

#define KEY_ESC         50000
#define KEY_HOME        50005
#define KEY_LEFT        50006
#define KEY_RIGHT       50007
#define KEY_UP          50008
#define KEY_DOWN        50009
#define KEY_END         50010
#define KEY_PGUP        50011
#define KEY_PGDOWN      50012
#define KEY_INSERT      50013
#define KEY_DEL         50014
#define KEY_F1          50015
#define KEY_F2          50016
#define KEY_F3          50017
#define KEY_F4          50018
#define KEY_F5          50019
#define KEY_F6          50020
#define KEY_F7          50021
#define KEY_F8          50022
#define KEY_F9          50023
#define KEY_F10         50024
#define KEY_F11         50025
#define KEY_F12         50026

#endif
