#ifndef _STDIO_COMMON_H_
#define _STDIO_COMMON_H_

#include <stdarg.h>

// Writes at most size characters (including terminal 0) of the formatted string fmt
// into buffer dest.
// args are the variable length arguments as a va_list.
// Returns the number of characters written.
// IMPORTANT: size must be <= 512
extern int vsnprintf(char *dest, int size, const char *fmt, va_list args);

#endif
