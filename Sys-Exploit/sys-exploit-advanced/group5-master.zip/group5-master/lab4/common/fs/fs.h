#ifndef _FS_COMMON_H_
#define _FS_COMMON_H_

#define ROUND_UP(size, block_size) (1+((long)size-1)/block_size)
	
#endif
