# Maximum Independent Set par Quentin Rod et Thomas Dagier

## Deploiement:
    - requiert xterm pour l'utilisation du script
        sudo apt-get update -y
        sudo apt-get install -y xterm

## Exécution:
    - ./script.sh X  (X est la node qui fait le INIT avec 1 <= X <= 36)
    ou
    - ./mis num_port neighbour-X.yaml INIT/WAIT

## Vérifications:

    Afin de vérifier que l'algorithme produit le bon résultat, la meilleure option est de comparer l'output de chaque terminal avec l'image network.png. 
    - Un noeud "winner" n'a que des voisins "looser".
    - Aucun noeud ne peut être sans état à la fin.
    - Il ne doit pas être possible de rajouter des noeuds "winner" dans le set de fin.
    - Un noeud "looser" est forcément à coté d'un noeud "winner"

![Network](network.png)