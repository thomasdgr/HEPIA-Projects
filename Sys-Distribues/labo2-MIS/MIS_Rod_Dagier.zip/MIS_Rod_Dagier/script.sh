PORT=50000

for i in {1..36}; do
    if [[ $1 -ne $i ]]
    then
        xterm -hold -e bash -c "./mis $PORT neighbour-$i.yaml WAIT" & disown
    fi
done

sleep 2
xterm -hold -e bash -c "./mis $PORT neighbour-$1.yaml INIT" & disown