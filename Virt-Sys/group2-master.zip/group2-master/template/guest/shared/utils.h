#ifndef _UTILS_H_
#define _UTILS_H_

#include <stdint.h>
#include <sys/types.h>

extern void memset(void *dst, uint8_t value, u_int count);

#endif