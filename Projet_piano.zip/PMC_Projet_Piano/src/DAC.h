#ifndef DAC_H
#define DAC_H

#include "lpc1769_reg.h"
void init_DAC(void);
#endif
