/*===============================================================================
 Name        : main_project.c
 Author      : Thomas Dagier
 Version     : 1.0
 Copyright   :
 Description : main definition
 Date : 11.06.2020
===============================================================================*/

#include "lpc1769_reg.h"
#include "utils.h"
#include "LCD.h"
#include "GPIO.h"
#include "DAC.h"
#include "I2C.h"
#include "exercices.h"

int main(void){
		SystemInit();
		init_i2c(0,400000);
		init_GPIO();
		init_LCD();
		init_DAC();
		init_timer();
		init_display();
		while(1){

		}
		return 0;
}
