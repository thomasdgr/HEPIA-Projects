#ifndef EXERCICES_H
#define EXERCICES_H

#include "GPIO.h"

void exercice1(void);
void exercice2(void);
void exercice3(void);
void exercice4(void);
void exercice5(void);
void exercice6(void);

#endif
