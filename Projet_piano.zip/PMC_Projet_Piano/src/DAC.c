/*===============================================================================
 Name        : DAC.c
 Author      : Thomas Dagier
 Version     : 1.0
 Copyright   :
 Description : initialisation du périphérique DAC
 Date : 11.06.2020
===============================================================================*/

#include "LCD.h"
#include "GPIO.h"
#include "DAC.h"

void init_DAC( void ){
	// activer le bit P0_26
	PINSEL1 &= ~0x00300000 ;
	PINSEL1 |= 0x00200000;
}
