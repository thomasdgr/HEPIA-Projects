/*===============================================================================
 Name        : exercices.c
 Author      : Thomas Dagier
 Version     : 1.0
 Copyright   :
 Description : librairie contenant les exercices fait en classe dont je me suis inspiré
 	 	 	 	 	  pour certaines parties du projet
 Date : 11.06.2020
===============================================================================*/

#include "GPIO.h"

// global variables
uint8_t exo;
uint32_t value_LED;

//   AFFICHAGE CLIGNOTANT
void exercice1(void){
	FIO2DIR = 0b10000001; // uniquement P2_7 ... ... et P2_0
	FIO2SET = 0b10000000; // le pin de P2_7 est à 1 : la LED s'allume
	DelaiMs(1000); // on attend a peu près une seconde
	FIO2CLR = 0b10000000; // on clear le pin de P2_7 : la LED s'éteint
	FIO2SET = 0b00000001; // on repète les memes etapes avec la sortie P2_0
	DelaiMs(350000);
	FIO2CLR = 0b00000001;
}

//   COMPTEUR 8 BITS A DEUX VITESSES
void exercice2(void){
	FIO2DIR = 0b11111111; // de P2_0 à P2_7
	FIO1PIN = 0b00000000; // uniquement P2_19
	FIO1MASK = 0xFFFFFFFF - pow(2,19);
	FIO1PIN = 1<<19; // uniquement P2_19
	uint32_t value_delay = 0;

	for(int i = 0; i < 256; i++){
		if(FIO1PIN == 0){
			value_delay = 500; // environ 500 ms
		} else { // si on appuie, FIO1PIN retourne 2^19
			value_delay = 1000; // environ 1 seconde
		}
		FIO2PIN += 1;
		DelaiMs(value_delay);
	}
}

//   COMPTEUR 8 BITS MANUEL
void exercice3(void){
	FIO2DIR = 0xFF; // de P2_0 à P2_7
	FIO1PIN = 0; // uniquement P2_19
	FIO1MASK = 0xFFFFFFFF - (1<<19);
	FIO1PIN = 1<<19; // uniquement P2_19
	int i = 0;
	while (i < 256){
		if(FIO1PIN == 0){
			FIO2PIN += 1;
			i++;
			while(FIO1PIN == 0){
				// on attend que le bouton soit laché
			}
		}
	}
}

//   CHENILLARD
void exercice4(void){
	FIO2DIR = 0b11111111;
	LetSetState8(0);
	uint8_t led = 0;
	uint8_t nb_led = 0;
	bool sens = true;
	uint8_t count = 0;
	while(1){
		uint8_t state = JoystickGetState();
		switch (state){
		case 0: break;
		case 1:
			nb_led++;
			if(nb_led == 7){
				nb_led = 0;
			}
			break;
		case 2: break;
		case 4:
			sens = false;
			break;
		case 16:
			sens = true;
			break;
		}
		if(sens){
			led++;
			if(led==8){
				led = 0;
			}
			for(uint8_t i = 0; i <= nb_led; i++){
				uint8_t led_inter = led + i;
				if (led_inter >= 8) {
					led_inter = 0 + count;
					count++;
				}
				LetSetState(led_inter,true);
			}
			count = 0;
		}else{
			if(led == 0){
				led = 8;
			}
			led--;
			for(uint8_t i = 0; i <= nb_led; i++){
				int8_t led_inter = led - i;
				if (led_inter < 0) {
					led_inter = 7 - count;
					count++;
				}
				LetSetState(led_inter,true);
			}
			count = 0;
		}
		DelaiMs(500);
		LetSetState8(0);
	}
}

// COMPTEUR 8 BITS MANUEL AVEC INTERRUPT
void exercice5(void){
	// initialisaiton
	FIO2DIR &= ~(1 << 10);
	FIO0DIR &= ~(1 << 19);
	FIO2DIR |= 0xFF;
	FIO2PIN = 0;
	FIO2MASK = 0;
	// initalisation pour les interrupt
	ISER0 |= (1 << 21);
	IO0IntEnF |= (1 << 19);
	IO2IntEnF |= (1 << 10);
	while (1){
		FIO2MASK = ~(0xFF);
		FIO2MASK = 0;
		LetSetState8(value_LED);
		DelaiMs_clk(10);
	}
}

//FAIRE CLIGNOTER UNE LED AVEC UN TIMER
void exercice6(void){
	// init led et btn
	FIO2DIR &= ~(1<<10); // btn A
	FIO2DIR |= 0xff; // leds
	// init interrupt
	IO2IntEnF |= (1<<10);
	ISER0 = (1<<21) | 2; //  interrupt +  timer0
	//init timer
	T0PR = 1000; // on passe de 1MHz à 1kHz soit 1ms (1'000'000 / 1'000)
	//T0CTCR &= ~3;
	T0TCR |= 1;
	T0MCR |= 9; //0b1001 active le match register 0 et 1
	T0MR0 = 2000; // attendre 2s pour allumer
	T0MR1 = 2500; // attendre 2.5s pour éteindre
	//le bouton déclenche le compteur
	while(1){
		// execution des interrputions et comptage du timer
	}
}
