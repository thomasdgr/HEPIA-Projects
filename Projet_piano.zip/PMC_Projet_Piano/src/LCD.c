/*===============================================================================
 Name        : LCD.c
 Author      : Thomas Dagier
 Version     : 1.0
 Copyright   :
 Description : fonctions de gestion de l'affichage
 Date : 11.06.2020
===============================================================================*/


#include "LCD.h"

/* P0.15 	SSP0_CLK 		SPI
	P0.18 	SSP0_MOSI 	SPI
	P0.17 	SSP0_MISO 	SPI
	P1.30 	LCD_DC 			GPIO dcx
	P0.16 	nCS_LCD 			GPIO slave select
	P1.18 	BL_ctrl 			GPIO backlight toujours à 1 */

void Write_Cmd(int value){
	FIO1CLR = 1<<30; // met le dc à 0
	FIO0CLR = 1<<16; // slave select
	S0SPDR = value; // prend en paramètre la commande que l'on veut faire
	while(!(S0SPSR&(1<<7))){
		// tant que l'envoie n'est pas terminé on attend (7e bit passe à 1)
	}
	// une fois que c'est terminé on stock pour effacer ce bit
	FIO1SET = 1<<16; // on clear le slave select
}

void Write_Cmd_Data(int value){
	FIO1SET = 1<<30;
	FIO0CLR = 1<<16;
	S0SPDR = value;
	while(!(S0SPSR&(1<<7))){
	}
	FIO1SET = 1<<16;
}

void ILI9341_Initial(void){
	Write_Cmd(0x01); //software reset
	DelaiMs_clk(5);

	Write_Cmd(0x11);
	DelaiMs_clk(120);

 	Write_Cmd(0xCF);
	Write_Cmd_Data(0x00);
	Write_Cmd_Data(0x83);
	Write_Cmd_Data(0X30);

 	Write_Cmd(0xED);
	Write_Cmd_Data(0x64);
	Write_Cmd_Data(0x03);
	Write_Cmd_Data(0X12);
	Write_Cmd_Data(0X81);

 	Write_Cmd(0xE8);
	Write_Cmd_Data(0x85);
	Write_Cmd_Data(0x01);
	Write_Cmd_Data(0x79);

 	Write_Cmd(0xCB);
	Write_Cmd_Data(0x39);
	Write_Cmd_Data(0x2C);
	Write_Cmd_Data(0x00);
	Write_Cmd_Data(0x34);
	Write_Cmd_Data(0x02);

 	Write_Cmd(0xF7);
	Write_Cmd_Data(0x20);

 	Write_Cmd(0xEA);
	Write_Cmd_Data(0x00);
	Write_Cmd_Data(0x00);


 	Write_Cmd(0xC1);    //Power control
	Write_Cmd_Data(0x11);   //SAP[2:0];BT[3:0]

 	Write_Cmd(0xC5);    //VCM control 1
	Write_Cmd_Data(0x34);
	Write_Cmd_Data(0x3D);

 	Write_Cmd(0xC7);    //VCM control 2
	Write_Cmd_Data(0xC0);

 	Write_Cmd(0x36);    // Memory Access Control
	Write_Cmd_Data(0x08);

 	Write_Cmd(0x3A);   	 // Pixel format
	Write_Cmd_Data(0x55);  //16bit

 	Write_Cmd(0xB1);   	   // Frame rate
	Write_Cmd_Data(0x00);
	Write_Cmd_Data(0x1D);  //65Hz

 	Write_Cmd(0xB6);    // Display Function Control
	Write_Cmd_Data(0x0A);
	Write_Cmd_Data(0xA2);
	Write_Cmd_Data(0x27);
	Write_Cmd_Data(0x00);

	Write_Cmd(0xb7); //Entry mode
	Write_Cmd_Data(0x07);


 	Write_Cmd(0xF2);    // 3Gamma Function Disable
	Write_Cmd_Data(0x08);

 	Write_Cmd(0x26);    //Gamma curve selected
	Write_Cmd_Data(0x01);


	Write_Cmd(0xE0); //positive gamma correction
	Write_Cmd_Data(0x1f);
	Write_Cmd_Data(0x1a);
	Write_Cmd_Data(0x18);
	Write_Cmd_Data(0x0a);
	Write_Cmd_Data(0x0f);
	Write_Cmd_Data(0x06);
	Write_Cmd_Data(0x45);
	Write_Cmd_Data(0x87);
	Write_Cmd_Data(0x32);
	Write_Cmd_Data(0x0a);
	Write_Cmd_Data(0x07);
	Write_Cmd_Data(0x02);
	Write_Cmd_Data(0x07);
	Write_Cmd_Data(0x05);
	Write_Cmd_Data(0x00);

	Write_Cmd(0xE1); //negamma correction
	Write_Cmd_Data(0x00);
	Write_Cmd_Data(0x25);
	Write_Cmd_Data(0x27);
	Write_Cmd_Data(0x05);
	Write_Cmd_Data(0x10);
	Write_Cmd_Data(0x09);
	Write_Cmd_Data(0x3a);
	Write_Cmd_Data(0x78);
	Write_Cmd_Data(0x4d);
	Write_Cmd_Data(0x05);
	Write_Cmd_Data(0x18);
	Write_Cmd_Data(0x0d);
	Write_Cmd_Data(0x38);
	Write_Cmd_Data(0x3a);
	Write_Cmd_Data(0x1f);

 	Write_Cmd(0x11);    //Exit Sleep
 	DelaiMs_clk(120);
 	Write_Cmd(0x29);    //Display on
 	DelaiMs_clk(50);
}

void init_LCD(){
	S0SPCR = (1<<5); // active le master du SPI
	S0SPCCR = 8; // set la clk au minimum
	PINSEL0 = (0b11 << 30); // initi signal clk
	PINSEL1 = (0b1111 << 2); // initi signal mosi et miso
	ILI9341_Initial();
}

uint16_t get_color(uint8_t R,uint8_t V,uint8_t B){
	if(R>31) R = 31;
	if(V>63) V = 63;
	if(B>31) B = 31;
	uint16_t couleur;
	couleur = (R << 11);
	couleur |= (V << 5);
	couleur |= (B<<0);
	return couleur;
}

void degrade_blue(uint8_t R,uint8_t V,uint8_t B){
	uint16_t couleur = 0;
	for (int i = 0 ; i< 320; i++){
		for (int j = 0; j < 240; j++){
			couleur = get_color(R,V,B);
			Write_Cmd_Data(couleur >> 8);
			Write_Cmd_Data(couleur);
		}
		if(i%10 == 0) B++;
	}
}

void define_fenetre(uint16_t li, uint16_t nb_li, uint16_t co, uint16_t nb_co){
	Write_Cmd(0x2A);
	Write_Cmd_Data(co>>8);
	Write_Cmd_Data(co);
	Write_Cmd_Data((co + nb_co)>>8);
	Write_Cmd_Data(co + nb_co);

	Write_Cmd(0x2B);
	Write_Cmd_Data(li>>8);
	Write_Cmd_Data(li);
	Write_Cmd_Data((li + nb_li)>>8);
	Write_Cmd_Data(li + nb_li);
}

void read_screen(){
	int result = 0;
	reset_fenetre(0,320,0,240);
	Write_Cmd_Data(0x2E);
	FIO1SET = 1<<30;
	for(int i = 0; i < 200; i++){
		FIO1SET = 1<<30;
		S0SPDR = 0;
		while(!((S0SPSR >>7)& 0b1)){

		}
		result = S0SPDR & 0xFF;
	}
	FIO0SET = 1<<16; // CS = 1
}

void reset_fenetre(int a, int b, int c, int d){
	define_fenetre(a,b,c,d);
	Write_Cmd(0x2C);
	for (int i = a ; i< b; i++){
		for (int j = c; j <  d; j++){
			Write_Cmd_Data(255);
			Write_Cmd_Data(255);
		}
	}
}

void suisse(){
	for (int i = 0 ; i< 320; i++){
		for (int j = 0; j < 240; j++){
			if((i>=80 && i<=240 && j>= 90 && j<=150)||(i>=130 && i<=190 && j>= 40 && j<=200)){
				Write_Cmd_Data(255);
				Write_Cmd_Data(255);
			} else {
				Write_Cmd_Data(0b11111000);
				Write_Cmd_Data(0);
			}
		}
	}
}

// afficher la fenetre et la colorer
void set_display(uint16_t a, uint16_t b, uint16_t c, uint16_t d, uint8_t color){
		define_fenetre(a,b,c,d);
		Write_Cmd(0x2C);
		for (int i = 0 ; i< 320; i++){
				for (int j = 0; j < 240; j++){
					Write_Cmd_Data(color);
					Write_Cmd_Data(color);
				}
		}
}

// afficher les touches du piano
void afficher_piano(void){
		set_display(0,35,0,160, 255);
		set_display(36,0,0,90, 0);
		set_display(37,34,0,160, 255);
		set_display(72,0,0,90, 0);
		set_display(73,34,0,160, 255);
		set_display(108,0,0,160, 0);
		set_display(109,34,0,160, 255);
		set_display(144,0,0,90, 0);
		set_display(145,35,0,160, 255);
		set_display(180,0,0,90, 0);
		set_display(181,34,0,160, 255);
		set_display(216,0,0,90, 0);
		set_display(217,33,0,160, 255);
		set_display(251,0,0,160, 0);
		set_display(252,33,0,160, 255);
		set_display(286,0,0,90, 0);
		set_display(287,32,0,160, 255);

		set_display(20,30,90,70,0);
		set_display(60,30,90,70,0);
		set_display(126,30,90,70,0);
		set_display(164,30,90,70,0);
		set_display(202,30,90,70,0);
		set_display(268,30,90,70,0);

		set_display(0,320,159,81,0);

}

void init_display(void){
	reset_fenetre(0,320,0,240);
	afficher_piano();
}

// vérifier que les coordonnées suite à l'appuie correspondent à une touche précise
bool in_touche(int x,int y,int x1_touche, int x2_touche, int y1_touche, int y2_touche){
	if((x >= x1_touche && x <= (x1_touche + x2_touche)) && ( y >= y1_touche && y <= (y1_touche + y2_touche))){
		return true;
	} else{
		return false;
	}
}

// en fonction de la touche -> jouer l'affichage si le bouton A a été pressé
// et retourner une valeur pour jouer un son cohérent
double detecter_touche(int x1,int y1,bool affichage){
	uint8_t color = 196;
	if(in_touche(x1,y1,0,35,0,160) && !in_touche(x1,y1,20,30,90,70)){
		if(affichage){
			set_display(0,20,0,160, color);
			set_display(20,15,0,89, color);
			set_display(0,20,0,160, 255);
			set_display(20,15,0,89, 255);
		}
		//do 1
		return 57;
	} else if(in_touche(x1,y1,20,30,90,70)){
		if(affichage){
			set_display(20,30,90,69, color);
			set_display(20,30,90,69, 0);
		}
		//do#
		return 55;
	} else if(in_touche(x1,y1,37,34,0,160) && !in_touche(x1,y1,20,30,90,70) && !in_touche(x1,y1,60,30,90,70)){
		if(affichage){
			set_display(37,13,0,89, color);
			set_display(50,10,0,160, color);
			set_display(60,11,0,89, color);
			set_display(37,13,0,89, 255);
			set_display(50,10,0,160, 255);
			set_display(60,11,0,89, 255);
		}
		//ré
		return 52;
	} else if(in_touche(x1,y1,60,30,90,70)){
		if(affichage){
			set_display(60,30,90,69, color);
			set_display(60,30,90,69, 0);
		}
		//ré#
		return 49;
	} else if(in_touche(x1,y1,73,34,0,160) && !in_touche(x1,y1,60,30,90,70)){
		if(affichage){
			set_display(73,17,0,89, color);
			set_display(90,17,0,160, color);
			set_display(73,17,0,89, 255);
			set_display(90,17,0,160, 255);
		}
		//mi
		return 46;
	}  else if(in_touche(x1,y1,109,34,0,160) && !in_touche(x1,y1,126,30,90,70)){
		if(affichage){
			set_display(109,16,0,160, color);
			set_display(126,17,0,89, color);
			set_display(109,16,0,160, 255);
			set_display(126,17,0,89, 255);
		}
		//fa
		return 43;
	} else if(in_touche(x1,y1,126,30,90,70)){
		if(affichage){
			set_display(126,30,90,69, color);
			set_display(126,30,90,69, 0);
		}
		//fa#
		return 41;
	} else if(in_touche(x1,y1,145,35,0,160) && !in_touche(x1,y1,126,30,90,70) && !in_touche(x1,y1,164,194,90,70)){
		if(affichage){
			set_display(145,11,0,89, color);
			set_display(156,8,0,160, color);
			set_display(164,15,0,89, color);
			set_display(145,11,0,89, 255);
			set_display(156,8,0,160, 255);
			set_display(164,15,0,89, 255);
		}
		//sol
		return 39;
	} else if(in_touche(x1,y1,164,30,90,70)){
		if(affichage){
			set_display(164,30,90,69, color);
			set_display(164,30,90,69, 0);
		}
		//sol#
		return 37;
	} else if(in_touche(x1,y1,181,34,0,160) && !in_touche(x1,y1,164,30,90,70) && !in_touche(x1,y1,202,30,90,70)){
		if(affichage){
			set_display(181,13,0,89, color);
			set_display(194,8,0,160, color);
			set_display(202,13,0,89, color);
			set_display(181,13,0,89, 255);
			set_display(194,8,0,160, 255);
			set_display(202,13,0,89, 255);
		}
		//la
		return 35;
	} else if(in_touche(x1,y1,202,30,90,70)){
		if(affichage){
			set_display(202,30,90,69, color);
			set_display(202,30,90,69, 0);
		}
		//la#
		return 33;
	} else if(in_touche(x1,y1,217,33,0,160) && !in_touche(x1,y1,202,30,90,70)){
		if(affichage){
			set_display(217,15,0,89, color);
			set_display(232,18,0,160, color);
			set_display(217,15,0,89, 255);
			set_display(232,18,0,160, 255);
		}
		//si
		return 32;
	} else if(in_touche(x1,y1,252,33,0,160) && !in_touche(x1,y1,268,30,90,70)){
		if(affichage){
			set_display(252,16,0,160, color);
			set_display(268,17,0,89, color);
			set_display(252,16,0,160, 255);
			set_display(268,17,0,89, 255);
		}
		//do
		return 30;
	} else if(in_touche(x1,y1,268,30,90,70)){
		if(affichage){
			set_display(268,30,90,69, color);
			set_display(268,30,90,69, 0);
		}
		//do#
		return 29;
	} else if(in_touche(x1,y1,287,32,0,160) && !in_touche(x1,y1,268,30,90,70)){
		if(affichage){
			set_display(287,11,0,89, color);
			set_display(298,21,0,160, color);
			set_display(287,11,0,89, 255);
			set_display(298,21,0,160, 255);
		}
		//ré
		return 27;
	} else {
		return 100000000;
	}
}

// les coordonnées données par I2C ne correspondent pas à la convention de l'écran
void miroir_point(uint16_t* x, uint16_t* y){
	*x = 320 - *x;
	*y = 240 - *y;
}
