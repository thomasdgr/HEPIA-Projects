/*===============================================================================
 Name        : lpc1769_reg.h.c
 Author      : Fabien Vannel
 Version     :
 Copyright   :
 Description : registres utilisés pour le projet
 Date : 26.04.2020
===============================================================================*/

#ifndef LPC1769_REG_H_
#define LPC1769_REG_H_

#define	FIO0DIR			(*((volatile uint32_t *) 0x2009C000))
#define	FIO0MASK		(*((volatile uint32_t *) 0x2009C010))
#define	FIO0PIN			(*((volatile uint32_t *) 0x2009C014))
#define	FIO0SET			(*((volatile uint32_t *) 0x2009C018))
#define	FIO0CLR			(*((volatile uint32_t *) 0x2009C01C))

#define	FIO1DIR			(*((volatile uint32_t *) 0x2009C020))
#define	FIO1MASK		(*((volatile uint32_t *) 0x2009C030))
#define	FIO1PIN			(*((volatile uint32_t *) 0x2009C034))
#define	FIO1SET			(*((volatile uint32_t *) 0x2009C038))
#define	FIO1CLR			(*((volatile uint32_t *) 0x2009C03C))

#define	FIO2DIR			(*((volatile uint32_t *) 0x2009C040))
#define	FIO2MASK		(*((volatile uint32_t *) 0x2009C050))
#define	FIO2PIN			(*((volatile uint32_t *) 0x2009C054))
#define	FIO2SET			(*((volatile uint32_t *) 0x2009C058))
#define	FIO2CLR			(*((volatile uint32_t *) 0x2009C05C))

#define	FIO3DIR			(*((volatile uint32_t *) 0x2009C060))
#define	FIO3MASK		(*((volatile uint32_t *) 0x2009C070))
#define	FIO3PIN			(*((volatile uint32_t *) 0x2009C074))
#define	FIO3SET			(*((volatile uint32_t *) 0x2009C078))
#define	FIO3CLR			(*((volatile uint32_t *) 0x2009C07C))

#define	FIO4DIR			(*((volatile uint32_t *) 0x2009C080))
#define	FIO4MASK		(*((volatile uint32_t *) 0x2009C090))
#define	FIO4PIN			(*((volatile uint32_t *) 0x2009C094))
#define	FIO4SET			(*((volatile uint32_t *) 0x2009C098))
#define	FIO4CLR			(*((volatile uint32_t *) 0x2009C09C))

#define	CCR					(*((volatile uint32_t *) 0xE000ED14))
#define	SysTick_CTRL	(*((volatile uint32_t *) 0xE000E010))
#define	SysTick_LOAD	(*((volatile uint32_t *) 0xE000E014))

#define 	ISER0 				(*((volatile uint32_t *) 0xE000E100))

#define 	IO0IntEnF 		(*((volatile uint32_t *) 0x40028094))
#define 	IO0IntClr 		(*((volatile uint32_t *) 0x4002808C))
#define 	IO0IntStatF	(*((volatile uint32_t *) 0x40028088))

#define 	IO2IntEnF 		(*((volatile uint32_t *) 0x400280B4))
#define 	IO2IntClr 		(*((volatile uint32_t *) 0x400280AC))
#define 	IO2IntStatF	(*((volatile uint32_t *) 0x400280A8))

#define 	PCONP 				(*((volatile uint32_t *) 0x400FC0C4))
#define 	PINSEL0			(*((volatile uint32_t *) 0x4002C000))
#define 	PINSEL1			(*((volatile uint32_t *) 0x4002C004))
#define 	PINSEL3			(*((volatile uint32_t *) 0x4002C00C))

#define 	S0SPCR			(*((volatile uint32_t *) 0x40020000))
#define   S0SPSR			(*((volatile uint32_t *) 0x40020004))
#define 	S0SPDR			(*((volatile uint32_t *) 0x40020008))
#define 	S0SPCCR			(*((volatile uint32_t *) 0x4002000C))
#define 	S0SPINT			(*((volatile uint32_t *) 0x4002001C))

#define 	STCTRL			(*((volatile uint32_t *) 0xE000E010))
#define 	STRELOAD		(*((volatile uint32_t *) 0xE000E014))
#define 	STCURR 			(*((volatile uint32_t *) 0xE000E018))
#define 	STCALIB			(*((volatile uint32_t *) 0xE000E01C))

// CLOCK
#define STCTRL 				(*((volatile uint32_t *) 0xE000E010))
#define STRELOAD			(*((volatile uint32_t *) 0xE000E014))
#define STCURR 			(*((volatile uint32_t *) 0xE000E018))
#define STCALIB			(*((volatile uint32_t *) 0xE000E01C))

//TIMER
#define T0IR 				    (*((volatile uint32_t *) 0x40004000))
#define T0TCR 				(*((volatile uint32_t *) 0x40004004))
#define T0TC    				(*((volatile uint32_t *) 0x40004008))
#define T0PR   				(*((volatile uint32_t *) 0x4000400C))
#define T0PC    				(*((volatile uint32_t *) 0x40004010))
#define T0MCR 				(*((volatile uint32_t *) 0x40004014))
#define T0MR0 				(*((volatile uint32_t *) 0x40004018))
#define T0MR1 				(*((volatile uint32_t *) 0x4000401C))
#define T0MR2 				(*((volatile uint32_t *) 0x40004020))
#define T0MR3 				(*((volatile uint32_t *) 0x40004024))
#define T0CCR 				(*((volatile uint32_t *) 0x40004028))
#define T0CR0 				(*((volatile uint32_t *) 0x4000402C))
#define T0CR1 				(*((volatile uint32_t *) 0x40004030))
#define T0EMR 				(*((volatile uint32_t *) 0x4000403C))
#define T0CTCR 				(*((volatile uint32_t *) 0x40004070))

#define MR0 					(*((volatile double *) 0x40018018))
#define MR1 					(*((volatile uint32_t *) 0x4001801C))

//SPI
#define S0SPCR 			    (*((volatile uint32_t *) 0x40020000))
#define S0SPSR				(*((volatile uint32_t *) 0x40020004))
#define S0SPDR				(*((volatile uint32_t *) 0x40020008))
#define S0SPCCR 			(*((volatile uint32_t *) 0x4002000C))
#define S0SPINT			(*((volatile uint32_t *) 0x4002001C))

// Syscon Miscellaneous Registers
#define SCS					(*((volatile uint32_t *) 0x400FC1A0))

// CLK SOURCE SELECTION
#define CLKSRCSEL		(*((volatile uint32_t *) 0x400FC10C))

// PLL0, Main PLL
#define PLL0CON			(*((volatile uint32_t *) 0x400FC080))
#define PLL0CFG				(*((volatile uint32_t *) 0x400FC084))
#define PLL0STAT			(*((volatile uint32_t *) 0x400FC088))
#define PLL0FEED			(*((volatile uint32_t *) 0x400FC08C))

// PLL1, UBS PLL
#define PLL1CON			(*((volatile uint32_t *) 0x400FC0A0))
#define PLL1CFG				(*((volatile uint32_t *) 0x400FC0A4))
#define PLL1STAT			(*((volatile uint32_t *) 0x400FC0A8))
#define PLL1FEED			(*((volatile uint32_t *) 0x400FC0AC))

// CLOCK DIVIDER
#define CCLKCFG			(*((volatile uint32_t *) 0x400FC104))
#define USBCLKCFG		(*((volatile uint32_t *) 0x400FC108))
#define PCLKSEL0			(*((volatile uint32_t *) 0x400FC1A8))
#define PCLKSEL1			(*((volatile uint32_t *) 0x400FC1AC))

// POWER CONTROL
#define PCON					(*((volatile uint32_t *) 0x400FC0C0))
#define PCONP				(*((volatile uint32_t *) 0x400FC0C4))

// Utility
#define CLKOUTCFG		(*((volatile uint32_t *) 0x400FC1C8))

// Flash Accelerator
#define FLASHCFG			(*((volatile uint32_t *) 0x400FC000))

// DAC
#define DACR		    		(*((volatile uint32_t *) 0x4008C000))
#define DACCTRL		    (*((volatile uint32_t *) 0x4008C004))
#define DACNTVAL			(*((volatile uint32_t *) 0x4008C008))

#endif /* LPC1769_REG_H_ */
