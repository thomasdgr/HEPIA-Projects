#ifndef GPIO_H
#define GPIO_H

#include "lpc1769_reg.h"
#include <stdint.h>
#include <stdbool.h>
#include <math.h>

/* function prototypes */
void init(void);
void LetSetState(uint8_t led, bool state);
void LetSetState8(uint8_t value);
uint8_t JoystickGetState(void);
uint8_t JoystickTestState(uint8_t pos);
void DelaiMs(uint32_t delai);
void DelaiMs_clk(double count);
void SysTick_Handler(void);
void GPIO_IRQHandler(void);
void TIMER0_IRQHandler(void);
void init_GPIO();
void init_timer();

#endif
