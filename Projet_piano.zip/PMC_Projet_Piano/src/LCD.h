#ifndef LCD_H
#define LCD_H

#include "GPIO.h"
#include "utils.h"

void Write_Cmd(int value);
void Write_Cmd_Data(int value);
void Delais(int count);
void ILI9341_Initial(void);
void init_LCD();
uint16_t get_color(uint8_t R,uint8_t V,uint8_t B);
void remplissage_fenetre(uint8_t value);
void degrade_blue(uint8_t R,uint8_t V,uint8_t B);
void degrade_red(uint8_t R,uint8_t V,uint8_t B);
void degrade_green(uint8_t R,uint8_t V,uint8_t B);
void define_fenetre(uint16_t li, uint16_t nb_li, uint16_t co, uint16_t nb_co);
void reset_fenetre(int a, int b, int c, int d);
void suisse();
void set_display(uint16_t a, uint16_t b, uint16_t c, uint16_t d, uint8_t color);
void afficher_piano(void);
double detecter_touche(int x1,int y1,bool affichage);
bool in_touche(int x,int y,int x1_touche, int x2_touche, int y1_touche, int y2_touche);
void miroir_point(uint16_t* x, uint16_t* y);
void init_display(void);

#endif
