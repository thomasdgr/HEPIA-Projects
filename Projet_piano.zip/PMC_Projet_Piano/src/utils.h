/*
 * UTILS.h
 *
 *  Created on: 26 Apr 2020
 *      Author: fabien
 */

#ifndef UTILS_H_
#define UTILS_H_

#include <stdint.h>
#include "lpc1769_reg.h"

void SystemInit(void);


#endif /* UTILS_H_ */
