/*===============================================================================
 Name        : Projet_Piano
 Author      : Thomas Dagier
 Version     : 1.0
 Copyright   : Projet de PMC encadré par Fabien Vannel
 Description : Piano multi-fonction 
 Date 		 : 11.06.2020
===============================================================================*/

informations sur le porjet:
	
 - Au démarrage, l'écran s'initialise seul, une fois que toutes les touches sont affichées
   il est possible d'appuyer sur l'écran pour jouer des sons. Au vu de la complexité
   à appuyer précisément sur les touches (déjà petites), j'ai fait le choix de supprimer de
   mon code la possibilité d'appuyer sur 2 touches à la fois pour faire des sons plus précis.

 - En appuyant sur le bouton A,un affichage différent permet de voir sur quelle touche
   on appuie (le son est moins précis à cause du temps pris pour afficher la touche)
   
 - En appuyant sur le bouton B, il est possible de changer de gamme ou de hauteur.
   On peut donc choisir entre des sinus de différentes périodes (son pur)
   un signal triangulaire (son complexe)
   un signal damped/decaying inversé (courbe exponentielle)
   un signal sawtooth (son complexe d'un synthétiseur de base)
  

Il ne devrait y avoir rien à changer dans le code ou à l'initialisation
à part build et debug sur la carte la première fois.   